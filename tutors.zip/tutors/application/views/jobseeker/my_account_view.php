<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('common/meta_tags'); ?>
	<title><?php echo $title;?></title>
	<?php $this->load->view('common/before_head_close'); ?>
	<link rel="stylesheet" href="https://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.7/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="<?php echo base_url('public/autocomplete/demo.css'); ?>">
	<style>
	.ui-button {
		margin-left: -1px;
	}
	.ui-button-icon-only .ui-button-text {
		padding: 0.35em;
	}
	.ui-autocomplete-input {
		margin: 0;
		padding: 0.48em 0 0.47em 0.45em;
	}
	</style>
</head>
<body>
	<?php $this->load->view('common/after_body_open'); ?>
	<div class="siteWraper">
		<!--Header-->
		<?php $this->load->view('common/header'); ?>
		<!--/Header-->
		<div class="container detailinfo">
			<div class="row"> <?php echo form_open_multipart('jobseeker/my_account',array('name' => 'account_form', 'id' => 'account_form', 'onSubmit' => 'return validate_account_form(this);'));?>
				<div class="col-md-3">
					<div class="dashiconwrp">
						<?php $this->load->view('jobseeker/common/jobseeker_menu'); ?>
					</div>
				</div>

				<div class="col-md-9">
					<?php echo $this->session->flashdata('msg');?>


					<!--Personal info-->
					<div class="formwraper">
						<div class="titlehead">Update Profile</div>
						<div class="formint">
							<div class="input-group <?php echo (form_error('full_name'))?'has-error':'';?>">
								<label class="input-group-addon">Full Name <span>*</span></label>
								<input name="full_name" type="text" class="form-control" id="full_name" placeholder="Full Name" value="<?php echo $row->first_name.' '.$row->last_name; ?>" maxlength="40">
								<?php echo form_error('full_name'); ?>
							</div>
							<div class="input-group <?php echo (form_error('father_name'))?'has-error':'';?>">
								<label class="input-group-addon">Father's Name </label>
								<input name="father_name" type="text" class="form-control" id="father_name" placeholder="Father Name" value="<?php echo $row->father_name; ?>" maxlength="40">
								<?php echo form_error('father_name'); ?>
							</div>
							<div class="input-group <?php echo (form_error('mother_name'))?'has-error':'';?>">
								<label class="input-group-addon">Mother's Name </label>
								<input name="mother_name" type="text" class="form-control" id="mother_name" placeholder="Mother Name" value="<?php echo $row->mother_name; ?>" maxlength="40">
								<?php echo form_error('mother_name'); ?>
							</div>
							<div class="input-group">
								<label class="input-group-addon">Email</label>
								<input type="email" class="form-control" disabled="disabled" value="<?php echo $row->email; ?>">
							</div>
							<div class="input-group <?php echo (form_error('dob_day'))?'has-error':'';?>">
								<label class="input-group-addon">Date of Birth <span>*</span></label>
								<select class="form-control width-auto" name="dob_day" id="dob_day">
									<option value="">Day</option>
									<?php
									$dob = explode('-', $row->dob);

									for($dy=1;$dy<=31;$dy++):
										$day =sprintf("%02s", $dy);
										$selected = ($dob[2]==$day)?'selected="selected"':'';
										?>
										<option value="<?php echo $day;?>" <?php echo $selected;?>><?php echo $day;?></option>
									<?php endfor;?>
								</select>
								<select class="form-control width-auto" name="dob_month" id="dob_month">
									<option value="">Month</option>
									<?php for($mnth=1;$mnth<=12;$mnth++):
										$month =sprintf("%02s", $mnth);
										$selected = ($dob[1]==$month)?'selected="selected"':'';
										$dummy_date = '2014-'.$month.'-'.'01';
										?>
										<option value="<?php echo $month;?>" <?php echo $selected;?>><?php echo date("M", strtotime($dummy_date));?></option>
									<?php endfor;?>
								</select>
								<select class="form-control width-auto" name="dob_year" id="dob_year">
									<option value="">Year</option>
									<?php for($year=date("Y")-10;$year>=1901;$year--):
										$selected = ($dob[0]==$year)?'selected="selected"':'';
										if(($dob[0]=='' && $year=='1980')){
											$selected = 'selected="selected"';
										}
										?>
										<option value="<?php echo $year;?>" <?php echo $selected;?>><?php echo $year;?></option>
									<?php endfor;?>
								</select>
								<?php echo form_error('dob_day'); echo form_error('dob_month'); echo form_error('dob_month'); ?>
							</div>
							<div class="input-group <?php echo (form_error('gender'))?'has-error':'';?>">
								<label class="input-group-addon">Gender <span>*</span></label>
								<select class="form-control" name="gender" id="gender">
									<option value="male" <?php echo ($row->gender=='male')?'selected':''; ?>>Male</option>
									<option value="female" <?php echo ($row->gender=='female')?'selected':''; ?>>Female</option>
								</select>
								<?php echo form_error('gender'); ?>
							</div>
							<div class="input-group <?php echo (form_error('religion'))?'has-error':'';?>">
								<label class="input-group-addon">Religion </label>
								<input name="religion" type="text" class="form-control" id="religion" placeholder="Religion" value="<?php echo $row->religion; ?>" maxlength="40">
								<?php echo form_error('religion'); ?>
							</div>
							<div class="input-group <?php echo (form_error('marital_status'))?'has-error':'';?>">
								<label class="input-group-addon">Marital Status <span>*</span></label>
								<select class="form-control" name="marital_status" id="marital_status">
									<option value="">-- Select --</option>
									<option value="married" <?php echo ($row->marital_status=='married')?'selected':''; ?>> Married </option>
									<option value="unmarried" <?php echo ($row->marital_status=='unmarried')?'selected':''; ?>>Unmarried</option>
									<option value="single" <?php echo ($row->marital_status=='single')?'selected':''; ?>> Single </option>
								</select>
								<?php echo form_error('marital_status'); ?>
							</div>
							<div class="input-group <?php echo (form_error('nationality'))?'has-error':'';?>">
								<label class="input-group-addon">Nationality <span>*</span></label>
								<input name="nationality" type="text" class="form-control" id="nationality" placeholder="Nationality" value="<?php echo $row->nationality; ?>" maxlength="40">
								<?php echo form_error('nationality'); ?>
							</div>
							<div class="input-group <?php echo (form_error('national_id'))?'has-error':'';?>">
								<label class="input-group-addon">National Id No </label>
								<input name="national_id" type="text" class="form-control" id="national_id" placeholder="National Id" value="<?php echo $row->national_id; ?>" maxlength="40">
								<?php echo form_error('national_id'); ?>
							</div>
							<div class="input-group <?php echo (form_error('present_address'))?'has-error':'';?>">
								<label class="input-group-addon">Present Address <span>*</span></label>
								<textarea class="form-control" name="present_address" id="present_address" placeholder="Present Address"><?php echo $row->present_address; ?></textarea>
								<?php echo form_error('present_address'); ?>
							</div>
							<div class="input-group <?php echo (form_error('permanent_address'))?'has-error':'';?>">
								<label class="input-group-addon">Permanent Address </label>
								<textarea class="form-control" name="permanent_address" id="permanent_address" placeholder="Permanent Address"><?php echo $row->permanent_address; ?></textarea>
								<?php echo form_error('permanent_address'); ?>
							</div>
							<div class="input-group <?php echo (form_error('country'))?'has-error':'';?>">
								<label class="input-group-addon">Current Country <span>*</span></label>
								<input name="country" type="text" class="form-control" id="country" value="<?php echo $row->country; ?>" />
								<?php echo form_error('country'); ?>
							</div>
							<div class="input-group <?php echo (form_error('city'))?'has-error':'';?>">
								<label class="input-group-addon">Current City <span>*</span></label>
								<input name="city" type="text" class="form-control" id="city_text" value="<?php echo $row->city; ?>" maxlength="50">
								<?php echo form_error('city'); ?>
							</div>
							<div class="input-group <?php echo (form_error('mobile'))?'has-error':'';?>">
								<label class="input-group-addon">Mobile Phone <span>*</span></label>
								<input name="mobile" type="text" class="form-control" id="mobile" value="<?php echo $row->mobile; ?>" maxlength="15" />
								<?php echo form_error('mobile'); ?>
							</div>
							<div class="input-group">
								<label class="input-group-addon">Home Phone</label>
								<input name="phone" type="text" class="form-control" id="phone" value="<?php echo $row->phone; ?>" maxlength="15">
							</div>
							<div class="input-group">
								<label class="input-group-addon"></label>
								<input type="submit" name="submit_button" id="submit_button" value="Update" class="btn btn-primary" />
							</div>
						</div>
					</div>
				</div>
				<!--/Job Detail-->
				<?php echo form_close();?>

			</div>
		</div>
		<?php $this->load->view('common/bottom_ads');?>
		<!--Footer-->
		<?php $this->load->view('common/footer'); ?>
		<?php $this->load->view('common/before_body_close'); ?>
		<script src="<?php echo base_url('public/js/validate_jobseeker.js');?>" type="text/javascript"></script>
		<script src="<?php echo base_url('public/autocomplete/jquery-1.4.4.js'); ?>"></script>
		<script src="<?php echo base_url('public/autocomplete/jquery.ui.core.js'); ?>"></script>
		<script src="<?php echo base_url('public/autocomplete/jquery.ui.widget.js'); ?>"></script>
		<script src="<?php echo base_url('public/autocomplete/jquery.ui.button.js'); ?>"></script>
		<script src="<?php echo base_url('public/autocomplete/jquery.ui.position.js'); ?>"></script>
		<script src="<?php echo base_url('public/autocomplete/jquery.ui.autocomplete.js'); ?>"></script>
		<script type="text/javascript"> var cy = '<?php echo set_value('country');?>'; </script>
		<script src="<?php echo base_url('public/autocomplete/action-js.js'); ?>"></script>
		<script type="text/javascript">
		$(document).ready(function(){
			$('button').css('display','none');
			if(cy!='Bangladesh' && cy!='')
			$(".ui-autocomplete-input.ui-widget.ui-widget-content.ui-corner-left").css('display','none');
		});
		</script>
	</body>
	</html>
