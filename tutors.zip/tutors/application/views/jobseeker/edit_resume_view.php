<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('common/meta_tags'); ?>
    <title><?php echo $title;?></title>
    <?php $this->load->view('common/before_head_close'); ?>
    <link href="<?php echo base_url('public/css/jquery-ui.css');?>" rel="stylesheet" type="text/css" />
</head>
<body>
    <?php $this->load->view('common/after_body_open'); ?>
    <div class="siteWraper">
        <!--Header-->
        <?php $this->load->view('common/header'); ?>
        <!--/Header-->
        <div class="container detailinfo">
            <div class="row">
                <div class="col-md-3">
                    <div class="dashiconwrp">
                        <?php $this->load->view('jobseeker/common/jobseeker_menu'); ?>
                    </div>
                </div>

                <div class="col-md-9">
                    <div id="msg"></div>
                    <div><?php echo $this->session->flashdata('msg');?></div>
                    <div class="formwraper">
                        <div class="titlehead">
                            <div class="row">
                                <div class="col-md-12"><b>Edit Resume</b></div>
                            </div>
                        </div>
                        <div class="">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs flex" role="tablist">
                                <li role="presentation" class="active"><a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">Personal</a></li>
                                <li role="presentation"><a href="#education" aria-controls="education" role="tab" data-toggle="tab">Education / Training</a></li>
                                <li role="presentation"><a href="#employment" aria-controls="employment" role="tab" data-toggle="tab">Employment</a></li>
                                <li role="presentation"><a href="#information" aria-controls="information" role="tab" data-toggle="tab">Other Information</a></li>
                                <li role="presentation"><a href="#uploadedresume" aria-controls="uploadedresume" role="tab" data-toggle="tab">Resume</a></li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="personal">
                                    <div class="userinfoWrp">
                                        <div class="col-md-3">
                                            <div class="uploadPhoto">
                                                <img src="<?php echo base_url($photo);?>"  />
                                            </div>
                                            <div class="stripBox">
                                                <form name="frm_js_up" id="frm_js_up" method="post" action="<?php echo base_url('jobseeker/edit_jobseeker/upload_photo');?>" enctype="multipart/form-data">
                                                    <input type="file" name="upload_pic" id="upload_pic" accept="image/*" style="display:none;">
                                                </form>
                                                <a href="javascript:;" class="btn btn-primary btn-sm btn-upload" title="Upload Photo"><i class="fa fa-upload"></i> Upload</a>
                                                <?php if($row->photo!=''):?>
                                                    <a href="javascript:;" class="btn btn-danger btn-sm remove pull-right" id="remove_pic" title="Delete Photo"><i class="fa fa-trash-o"></i> Remove</a>
                                                <?php endif;?>
                                            </div>
                                        </div>
                                        <div class="col-md-8 col-md-offset-1">
                                            <h1 class="username"><?php echo $row->first_name.' '.$row->last_name;?></h1>
                                            <div class="comtxt"></div>
                                            <br>
                                            <div class="row">
                                                <div class="usercel"><label class="col-xs-4">Father </label> <?php echo $row->father_name;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Mother </label> <?php echo $row->mother_name;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Mobile </label> <?php echo $row->mobile;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Email </label> <?php echo $row->email;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Date of Birth </label> <?php echo $row->dob;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Gender </label> <?php echo $row->gender;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Religion </label> <?php echo $row->religion;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Marital Status </label> <?php echo $row->marital_status;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Nationality </label> <?php echo $row->nationality;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">National Id No </label> <?php echo $row->national_id;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Address </label> <?php echo $row->present_address;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">City </label> <?php echo $row->city;?>&nbsp;</div>
                                                <div class="usercel"><label class="col-xs-4">Country </label> <?php echo $row->country;?>&nbsp;</div>
                                            </div>
                                            <a href="<?php echo base_url('jobseeker/my_account');?>" id="edit_jobseeker_profileee" class="editLink btn btn-link"><i class="fa fa-pencil">&nbsp;</i> Edit Profile</a>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                    <!--Education-->
                                    <div class="innerbox2">
                                        <div class="titlebar">
                                            <div class="row">
                                                <div class="col-md-9"><b>Career and Application Information</b></div>
                                            </div>
                                        </div>

                                        <!--Job Description-->
                                        <div class="experiance">
                                            <div class="row expbox">
                                                <div class="col-md-12">
                                                    <div class="pull-right">
                                                        <a href="<?php echo base_url('jobseeker/career_info');?>" title="Edit" class="edit-ico btn btn-link"><i class="fa fa-pencil">&nbsp;</i> Edit </a>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="career_objective">
                                                        <label>Objective: </label>
                                                        <p><?php echo ($row_additional->description)?character_limiter($row_additional->description,500):' - ';?></p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <ul class="useradon">
                                                        <li><span>Present Salary: </span><?php echo $row_additional->salary;?></li>
                                                        <li><span>Looking for (Job Level): </span><?php echo $row_additional->job_level;?></li>
                                                    </ul>
                                                </div>
                                                <div class="col-md-6">
                                                    <ul class="useradon">
                                                        <li><span>Expected Salary: </span><?php echo $row_additional->expected_salary;?></li>
                                                        <li><span>Available for (Job Nature): </span><?php echo $row_additional->job_nature;?></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="education">

                                    <!--Education-->
                                    <div class="innerbox2">
                                        <div class="titlebar">
                                            <div class="row">
                                                <div class="col-md-9"><b>Education</b></div>
                                                <div class="col-md-3 text-right"><a href="javascript:;" id="add_education" class=" btn btn-link"><i class="fa fa-plus">&nbsp;</i> Add Another</a></div>
                                            </div>
                                        </div>

                                        <!--Job Description-->
                                        <div class="experiance">
                                            <?php
                                            if($result_qualification):
                                                foreach($result_qualification as $row_qualification):
                                                    ?>
                                                    <div class="row expbox" id="edu_<?php echo $row_qualification->ID;?>">
                                                        <div class="col-md-12">
                                                            <div class="pull-right">
                                                                <a href="javascript:;" onClick="load_edit_js_edu(<?php echo $row_qualification->ID;?>);" title="Edit" class="edit-ico btn btn-link"><i class="fa fa-pencil">&nbsp;</i> Edit </a>
                                                                <a href="javascript:;" onClick="del_edu(<?php echo $row_qualification->ID;?>);" title="Delete" class="delete-ico btn btn-link"><i class="fa fa-trash-o">&nbsp;</i> Delete</a>
                                                            </div>
                                                            <h4><span>Institute Name:</span> <?php echo $row_qualification->institute;?>, <?php echo $row_qualification->city;?></h4>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <ul class="useradon">
                                                                <li><span>Exam/Degree Title: </span><?php echo $row_qualification->degree_title;?></li>
                                                                <li><span>Concentration/ Major/Group: </span><?php echo $row_qualification->major;?></li>
                                                                <li><span>Country: </span><?php echo $row_qualification->country;?></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <ul class="useradon">
                                                                <li><span>Grade: </span><?php echo $row_qualification->grade;?></li>
                                                                <li><span>Year of Passing: </span><?php echo $row_qualification->completion_year;?></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <?php
                                                endforeach;
                                            endif;?>
                                            <div class="clear"></div>
                                        </div>
                                    </div>

                                    <!--Education-->
                                    <div class="innerbox2">
                                        <div class="titlebar">
                                            <div class="row">
                                                <div class="col-md-9"><b>Training</b></div>
                                                <div class="col-md-3 text-right"><a href="javascript:;" id="add_training" class=" btn btn-link"><i class="fa fa-plus">&nbsp;</i> Add Another</a></div>
                                            </div>
                                        </div>

                                        <!--Job Description-->
                                        <div class="experiance">
                                            <?php
                                            if($result_training):
                                                $count = 1;
                                                foreach($result_training as $row_training):
                                                    ?>
                                                    <div class="row expbox" id="training_<?php echo $row_training->ID;?>">
                                                        <div class="col-md-12">
                                                            <div class="pull-right">
                                                                <a href="javascript:;" onClick="load_edit_js_training(<?php echo $row_training->ID;?>);" title="Edit" class="edit-ico btn btn-link"><i class="fa fa-pencil">&nbsp;</i> Edit </a>
                                                                <a href="javascript:;" onClick="del_training(<?php echo $row_training->ID;?>);" title="Delete" class="delete-ico btn btn-link"><i class="fa fa-trash-o">&nbsp;</i> Delete</a>
                                                            </div>
                                                            <h4>Training <?= $count++ ?></h4>
                                                        </div>
                                                        <div class="col-md-8">
                                                            <ul class="useradon">
                                                                <li><span>Training Title: </span><?php echo $row_training->title;?></li>
                                                                <li><span>Topics Covered: </span><?php echo $row_training->topic_covered;?></li>
                                                                <li><span>Institute : </span><?php echo $row_training->institute ;?></li>
                                                                <li><span>Location : </span><?php echo $row_training->location ;?></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <ul class="useradon">
                                                                <li><span>City: </span><?php echo $row_training->city;?></li>
                                                                <li><span>Country: </span><?php echo $row_training->country;?></li>
                                                                <li><span>Training Year: </span><?php echo $row_training->year;?></li>
                                                                <li><span>Duration: </span><?php echo $row_training->duration;?></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <?php
                                                endforeach;
                                            endif;?>
                                            <div class="clear"></div>
                                        </div>
                                    </div>

                                </div>
                                <div role="tabpanel" class="tab-pane" id="employment">
                                    <!--Experiance-->
                                    <div class="innerbox2">
                                        <div class="titlebar">
                                            <div class="row">
                                                <div class="col-md-9"><b>Experience</b></div>
                                                <div class="col-md-3 text-right"><a href="javascript:;" id="add_exp" class=" btn btn-link"><i class="fa fa-plus">&nbsp;</i> Add Another</a></div>
                                            </div>
                                        </div>

                                        <!--Job Description-->
                                        <div class="experiance">
                                            <?php
                                            if($result_experience):
                                                foreach($result_experience as $row_experience):
                                                    $date_to = ($row_experience->end_date)?date_formats($row_experience->end_date, 'M Y'):'Present';
                                                    ?>
                                                    <div class="row expbox" id="exp_<?php echo $row_experience->ID;?>">
                                                        <div class="col-md-12">
                                                            <div class="pull-right">
                                                                <a href="javascript:;" onClick="load_edit_js_exp(<?php echo $row_experience->ID;?>);" title="Edit" class="edit-ico btn btn-link"><i class="fa fa-pencil">&nbsp;</i> Edit </a>
                                                                <a href="javascript:;" onClick="del_exp(<?php echo $row_experience->ID;?>);" title="Delete" class="delete-ico btn btn-link"><i class="fa fa-trash-o">&nbsp;</i> Delete </a>
                                                            </div>
                                                            <h4 class="company"><span>Company Name: </span><?php echo $row_experience->company_name;?></h4>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <ul class="useradon">
                                                                <li><span>Company Business: </span> <?php echo $row_experience->company_business;?></li>
                                                                <li><span>Designation: </span> <?php echo $row_experience->job_title;?></li>
                                                                <li><span>Department: </span> <?php echo $row_experience->department;?></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <ul class="useradon">
                                                                <li><span>Responsibilities: </span><?php echo $row_experience->responsibilities;?></li>
                                                                <li><span>Employment Period: </span><?php echo date_formats($row_experience->start_date, 'M Y');?> to <?php echo $date_to;?></li>
                                                                <li><span>Location: </span><?php echo $row_experience->city;?>, <?php echo $row_experience->country;?></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <?php
                                                endforeach;
                                            endif;?>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="information">

                                    <!--Languages-->
                                    <div class="innerbox2">
                                        <div class="titlebar">
                                            <div class="row">
                                                <div class="col-md-9"><b>My Additional Information</b></div>
                                                <div class="col-md-3 text-right"><a href="<?php echo base_url('jobseeker/additional_info');?>"><i class="fa fa-pencil"></i> Edit</a></div>
                                            </div>
                                        </div>

                                        <div class="experiance">
                                            <ul class="myjobList">
                                                <li>
                                                    <div class="row">
                                                        <label class="col-md-4">Interest:</label>
                                                        <div class="col-md-8">
                                                            <?php echo ($row_additional->interest)?character_limiter($row_additional->interest,150):' - ';?>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="row">
                                                        <label class="col-md-4">Achievements:</label>
                                                        <div class="col-md-8">
                                                            <?php echo ($row_additional->awards)?character_limiter($row_additional->awards,350):' - ';?>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="row">
                                                        <label class="col-md-4">Professional Summary:</label>
                                                        <div class="col-md-8">
                                                            <?php echo ($row_additional->summary)?character_limiter($row_additional->summary,500):' - '?>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="innerbox2">
                                        <div class="titlebar">
                                            <div class="row">
                                                <div class="col-md-9"><b>Language Proficiency</b></div>
                                                <div class="col-md-3 text-right"><a href="javascript:;" id="add_language" class=" btn btn-link"><i class="fa fa-plus">&nbsp;</i> Add Another</a></div>
                                            </div>
                                        </div>

                                        <!--Job Description-->
                                        <div class="experiance">
                                            <?php
                                            if($result_proficiency){
                                                $count = 1;
                                                foreach($result_proficiency as $row_proficiency) {
                                                    ?>
                                                    <div class="row expbox" id="language_<?php echo $row_proficiency->ID;?>">
                                                        <div class="col-md-12">
                                                            <div class="pull-right">
                                                                <a href="javascript:;" onClick="load_edit_js_language(<?php echo $row_proficiency->ID;?>);" title="Edit" class="edit-ico btn btn-link"><i class="fa fa-pencil">&nbsp;</i> Edit </a>
                                                                <a href="javascript:;" onClick="del_language(<?php echo $row_proficiency->ID;?>);" title="Delete" class="delete-ico btn btn-link"><i class="fa fa-trash-o">&nbsp;</i> Delete </a>
                                                            </div>
                                                            <h4> Language <?= $count++ ?></h4>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <ul class="useradon">
                                                                <li><span>language: </span><?php echo $row_proficiency->language;?></li>
                                                                <li><span>writing: </span><?php echo $row_proficiency->writing;?></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <ul class="useradon">
                                                                <li><span>reading: </span><?php echo $row_proficiency->reading;?></li>
                                                                <li><span>speaking: </span><?php echo $row_proficiency->speaking;?></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>
                                            <div class="clear"></div>
                                        </div>
                                    </div>

                                    <div class="innerbox2">
                                        <div class="titlebar">
                                            <div class="row">
                                                <div class="col-md-9"><b>Reference</b></div>
                                                <?php
                                                if(count($result_references) < 2) {
                                                    ?>
                                                    <div class="col-md-3 text-right"><a href="javascript:;" id="add_reference" class=" btn btn-link"><i class="fa fa-plus">&nbsp;</i> Add Another</a></div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>

                                        <!--Job Description-->
                                        <div class="experiance">
                                            <?php
                                            if($result_references){

                                                $count = 1;
                                                foreach($result_references as $row_reference){
                                                    ?>
                                                    <div class="row expbox" id="reference_<?php echo $row_reference->ID;?>">
                                                        <div class="col-md-12">
                                                            <div class="pull-right">
                                                                <a href="javascript:;" onClick="load_edit_js_reference(<?php echo $row_reference->ID;?>);" title="Edit" class="edit-ico btn btn-link"><i class="fa fa-pencil">&nbsp;</i> Edit </a>
                                                                <a href="javascript:;" onClick="del_exp(<?php echo $row_reference->ID;?>);" title="Delete" class="delete-ico btn btn-link"><i class="fa fa-trash-o">&nbsp;</i> Delete </a>
                                                            </div>
                                                            <h4>Reference <?= $count++ ?></h4>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <ul class="useradon">
                                                                <li><span>Name: </span><?php echo $row_reference->name;?></li>
                                                                <li><span>Designation: </span> <?php echo $row_reference->designation;?></li>
                                                                <li><span>Mobile: </span> <?php echo $row_reference->mobile;?></li>
                                                                <li><span>Email: </span> <?php echo $row_reference->email;?></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <ul class="useradon">
                                                                <li><span>Relation: </span> <?php echo $row_reference->relation;?></li>
                                                                <li><span>Organaization: </span><?php echo $row_reference->organaization;?></li>
                                                                <li><span>Phone (office): </span><?php echo $row_reference->phone;?></li>
                                                                <li><span>Address: </span><?php echo $row_reference->address;?></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <?php
                                                }
                                            }
                                            ?>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                </div>

                                <div role="tabpanel" class="tab-pane" id="uploadedresume">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <a href="javascript:;" class="btn btn-primary upload_cv" title="Upload Resume"> <i class="fa fa-plus">&nbsp;</i> Upload CV</a> </a>
                                            <form name="frm_js_up_cv" id="frm_js_up_cv" method="post" action="<?php echo base_url('jobseeker/edit_jobseeker/upload_cv');?>" enctype="multipart/form-data"><input type="file" name="upload_resume" id="upload_resume" style="display:none;"></form>
                                        </div>
                                    </div>
                                    <!--Job Description-->
                                    <div class="companydescription">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <ul class="myjobList">
                                                    <?php
                                                    if($result_resume){
                                                        foreach($result_resume as $row_resume){
                                                            $file_name = ($row_resume->is_uploaded_resume)?$row_resume->file_name:'';
                                                            $file_array = explode('.',$file_name);
                                                            $file_array = array_reverse($file_array);
                                                            $icon_name = get_extension_name($file_array[0]);
                                                            ?>
                                                            <li class="row" id="cv_<?php echo $row_resume->ID;?>">
                                                                <div class="col-md-4">
                                                                    <i class="fa fa-file-<?php echo $icon_name;?>-o">&nbsp;</i>
                                                                    <?php
                                                                    if($row_resume->is_uploaded_resume){
                                                                        ?>
                                                                        <a href="<?php echo base_url('resume/download/'.$row_resume->file_name);?>">My Resume</a>
                                                                        <?php
                                                                    } else {
                                                                        ?>
                                                                        <a href="#">My Resume</a>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <div class="col-md-4"><?php echo date_formats($row_resume->dated, "d M, Y");?></div>
                                                                <!-- <div class="col-md-2"><?php echo ($row_resume->is_default_resume=='yes')?'Default':'Mark as Default';?></div> -->
                                                                <div class="col-md-4 text-right"> <a href="javascript:;" onClick="del_cv(<?php echo $row_resume->ID;?>, '<?php echo $row_resume->file_name;?>')" title="Delete" class="delete-ico"><i class="fa fa-times">&nbsp;</i></a></div>
                                                            </li>
                                                            <?php
                                                        }
                                                    } else {
                                                        ?>
                                                        No resume uploaded yet!
                                                        <?php
                                                    }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



















                    </div>
                </div>
                <!--/Job Detail-->
            </div>
        </div>
        <?php $this->load->view('common/bottom_ads');?>
        <!--Footer-->
        <?php $this->load->view('common/footer'); ?>
        <!-- Profile Popups -->
        <?php $this->load->view('jobseeker/common/jobseekes_popup_forms'); ?>
        <?php $this->load->view('common/before_body_close'); ?>
        <script src="<?php echo base_url('public/js/jquery-ui.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('public/js/validate_jobseeker.js');?>" type="text/javascript"></script>
    </body>
    </html>
