<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('common/meta_tags'); ?>
    <title><?php echo $title;?></title>
    <link href="https://fonts.googleapis.com/css?family=Noticia+Text" rel="stylesheet">
    <?php $this->load->view('common/before_head_close'); ?>
    <link href="<?php echo base_url('public/css/jquery-ui.css');?>" rel="stylesheet" type="text/css" />
</head>
<body>
    <?php $this->load->view('common/after_body_open'); ?>
    <div class="siteWraper">
        <!--Header-->
        <?php $this->load->view('common/header'); ?>
        <!--/Header-->
        <div class="container detailinfo">
            <div class="row">
                <div class="col-md-3">
                    <div class="dashiconwrp">
                        <?php $this->load->view('jobseeker/common/jobseeker_menu'); ?>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="formwraper">
                        <div class="titlehead">View Resume</div>
                        <div class="formint">
                            <div class="companydescription cv-view">
                                <div id="resume" class="resume">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <p class="download-link">Download Resume:
                                                <a href="javascript:;" data-url="<?php echo base_url('jobseeker/resume_download');?>" id="resume_download" title="save cv in word">
                                                    <img src="<?php echo base_url('public/images/word.gif') ?>" alt="save cv in word">
                                                </a>
                                            </p>
                                            <h3><strong><?php echo $row->first_name.' '.$row->last_name;?></strong></h3>
                                            <p><?php echo $row->present_address;?>, <?php echo $row->city;?>, <?php echo $row->country;?></p>
                                            <p>Mobile No: <?php echo $row->mobile;?></p>
                                            <p>e-mail : <?php echo $row->email;?></p>
                                        </div>
                                        <div class="col-md-3 col-md-offset-1">
                                            <div class="cv-img">
                                                <img src="<?php echo file_exists('public/uploads/candidate/'.$photo) ? base_url('public/uploads/candidate/'.$photo) : "";?>" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Career Objective:</h4>
                                            <p><?php echo ($row_additional->description)?character_limiter($row_additional->description,500):' - ';?></p>
                                        </div>
                                    </div>
                                    <?php
                                    if($result_experience){
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4>Employment History:</h4>
                                                <?php
                                                $i = 1;
                                                foreach ($result_experience as $key => $exp) {
                                                    ?>
                                                    <div class="employment-history">
                                                        <p>
                                                            <span class="count"><?= $i++ ?>.</span> <span class="title"><?= $exp->job_title ?>, <?= $exp->department ?>
                                                                ( <?= date('F d, Y', strtotime($exp->start_date)) ?> - <?= isset($exp->end_date) ? date('F d, Y', strtotime($exp->end_date)) : 'Continuing'; ?>)
                                                            </span>
                                                        </p>
                                                        <p class="company"><?= $exp->company_name ?></p>
                                                        <p>Company Location : <?= $exp->city ?>, <?= $exp->country ?></p>
                                                        <p>Department: <?= $exp->department ?></p>
                                                        <p class="title">Duties/Responsibilities:</p>
                                                        <p><?= $exp->responsibilities ?></p>
                                                    </div>
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    if($result_training){
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4>Training Summary:</h4>
                                                <table class="table table-responsive table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Training Title</th>
                                                            <th>Topic</th>
                                                            <th>Institute</th>
                                                            <th>Country</th>
                                                            <th>Location</th>
                                                            <th>Year</th>
                                                            <th>Duration</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        foreach($result_training as $row_training){
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $row_training->title;?></td>
                                                                <td><?php echo $row_training->topic_covered;?></td>
                                                                <td><?php echo $row_training->institute;?></td>
                                                                <td><?php echo $row_training->country;?></td>
                                                                <td><?php echo $row_training->location;?></td>
                                                                <td><?php echo $row_training->year;?></td>
                                                                <td><?php echo $row_training->duration;?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div class="col-md-12">
                                        <h4>Career and Application Information:</h4>
                                        <table class="table table-responsive p-deatils">
                                            <tbody>
                                                <tr>
                                                    <td width="22%" align="left">Present Salary:</td>
                                                    <td width="2%" align="center">:</td>
                                                    <td width="76%" align="left"><?php echo $row_additional->salary; ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="22%" align="left">Expected Salary</td>
                                                    <td width="2%" align="center">:</td>
                                                    <td width="76%" align="left"><?php echo $row_additional->expected_salary; ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="22%" align="left">Looking for (Job Level)</td>
                                                    <td width="2%" align="center">:</td>
                                                    <td width="76%" align="left"><?php echo $row_additional->job_level;?></td>
                                                </tr>
                                                <tr>
                                                    <td width="22%" align="left">Available for (Job Nature):</td>
                                                    <td width="2%" align="center">:</td>
                                                    <td width="76%" align="left"><?php echo $row_additional->job_nature; ?></td>
                                                </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                    <?php
                                    if($result_qualification){
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4>Academic Qualification:</h4>
                                                <table class="table table-responsive table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Exam Title</th>
                                                            <th>Concentration/Major</th>
                                                            <th>Institute</th>
                                                            <th>Result</th>
                                                            <th>Pas.Year</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        foreach($result_qualification as $row_qualification){
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $row_qualification->degree_title;?></td>
                                                                <td><?php echo $row_qualification->major;?></td>
                                                                <td><?php echo $row_qualification->institute;?>, <?php echo $row_qualification->city;?></td>
                                                                <td><?php echo $row_qualification->grade;?></td>
                                                                <td><?php echo $row_qualification->completion_year;?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    if($result){
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4>Specialization:</h4>
                                                <table class="table table-responsive table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Fields of Specialization</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <ul>
                                                                    <?php
                                                                    foreach($result as $skill_row){
                                                                        if(trim($skill_row->skill_name)!=''){
                                                                            ?>
                                                                            <li><?php echo trim($skill_row->skill_name);?></li>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </ul>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    if($result_proficiency){
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4>Language Proficiency:</h4>
                                                <table class="table table-responsive table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Language</th>
                                                            <th>Reading</th>
                                                            <th>Writing</th>
                                                            <th>Speaking</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        foreach($result_proficiency as $row_proficiency){
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $row_proficiency->language;?></td>
                                                                <td><?php echo $row_proficiency->reading;?></td>
                                                                <td><?php echo $row_proficiency->writing;?></td>
                                                                <td><?php echo $row_proficiency->speaking;?></td>

                                                            </tr>
                                                            <?php
                                                        }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Personal Details :</h4>
                                            <table class="table table-responsive p-deatils">
                                                <tbody>
                                                    <tr>
                                                        <td width="22%" align="left">Father's Name</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->father_name; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Mother's  Name</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->mother_name; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Date of Birth</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->dob;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Gender</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->gender;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Marital Status</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->marital_status;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Nationality</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->nationality;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Religion</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->religion;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Permanent  Address</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->permanent_address;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td width="22%" align="left">Current Location</td>
                                                        <td width="2%" align="center">:</td>
                                                        <td width="76%" align="left"><?php echo $row->city;?>, <?php echo $row->country;?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <?php
                                    if($result_references){
                                        $store_array = [];
                                        $count = 0;
                                        foreach($result_references as $row_references){
                                            $store_array[$count++] = $row_references;
                                        }
                                        ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <h4>Reference :</h4>
                                                <table class="table table-responsive p-deatils">
                                                    <tbody>
                                                        <tr>
                                                            <td width="22%" align="left">&nbsp;</td>
                                                            <td width="2%" align="center">&nbsp;</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><u>Reference: 01</u></td>
                                                            <td width="41%" align="left"><u>Reference: 02</u></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">Name</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->name; ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->name; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">Organaization:</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->organaization; ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->organaization; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">Designation</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->designation;  ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->designation; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">Address</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->address; ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->address; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">Phone (off.)</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->phone ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->phone; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">Mobile</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->mobile; ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->mobile; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">E-mail</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->email; ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->email; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td width="22%" align="left">Relation</td>
                                                            <td width="2%" align="center">:</td>
                                                            <td width="35%" align="left" style="border-right:1px solid #666666;"><?php echo $store_array[0]->relation; ?></td>
                                                            <td width="41%" align="left"><?php echo $store_array[1]->relation; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                            <!-- Table View -->
                        </div>
                        <!-- /Table View -->
                    </div>
                </div>
            </div>
        </div>
        <?php $this->load->view('common/bottom_ads');?>
        <!--Footer-->
        <?php $this->load->view('common/footer'); ?>
        <!-- Profile Popups -->
        <?php $this->load->view('jobseeker/common/jobseekes_popup_forms'); ?>
        <?php $this->load->view('common/before_body_close'); ?>
        <script src="<?php echo base_url('public/js/jquery-ui.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('public/js/validate_jobseeker.js');?>" type="text/javascript"></script>
    </body>
    </html>
