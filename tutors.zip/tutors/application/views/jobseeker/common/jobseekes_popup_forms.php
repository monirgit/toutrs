<!-- Starts Edit Jobseeker Profile -->
<div class="modal fade" id="edit_profile_modal">
    <div class="modal-dialog">

        <form name="frm_edit_profile" id="frm_edit_profile" role="form" method="post" action="<?php echo base_url('');?>" onsubmit="return validate_cv_builder_form(this);">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Profile</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_profle"></div>
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" class="form-control"  id="full_name" name="full_name" value="<?php echo $row->first_name.' '.$row->last_name;?>" placeholder="Full Name">
                            <?php echo form_error('full_name'); ?>
                        </div>

                        <div class="form-group">
                            <label>Mobile Number</label>
                            <input type="text" class="form-control"  id="mobile" name="mobile" value="<?php echo $row->mobile;?>" placeholder="Mobile Number">
                            <?php echo form_error('mobile'); ?>

                        </div>
                        <input name="country" type="hidden" id="country" value="Bangladesh" />
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control"  id="city" name="city" value="<?php echo $row->city;?>" placeholder="City">
                            <?php echo form_error('city'); ?>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="jobseeker_profile_submitter" id="jobseeker_profile_submitter" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends Edit Jobseeker Profile -->
<!-- Starts Edit Jobseeker Profile Description-->
<div class="modal fade" id="edit_profile_summary_modal">
    <div class="modal-dialog">
        <form name="frm_seeker_summary" id="frm_seeker_summary" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Update Professional Summary</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_summary"></div>
                        <div class="form-group">
                            <label>Summary</label>
                            <textarea id="content" name="content"  class="form-control" rows="9" placeholder=""><?php echo ($row_additional->bad_habits)?$row_additional->summary:'';?></textarea>
                            <?php echo form_error('content'); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="summary_submit" id="summary_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends Edit Jobseeker Profile Description-->
<!-- Starts add Jobseeker Education-->
<div class="modal fade" id="add_education_modal">
    <div class="modal-dialog">

        <form name="frm_add_education" id="frm_add_education" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Education Information</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_add_edu"></div>
                        <div class="form-group">
                            <label>Degree Title</label>
                            <select name="degree_title" id="degree_title" class="form-control">
                                <option value="" selected="selected">Degree Title</option>
                                <?php foreach($result_degrees as $row_degree): ?>
                                    <option value="<?php echo $row_degree->val;?>"><?php echo $row_degree->text;?></option>
                                <?php endforeach;?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Major Subject</label>
                            <input type="text" class="form-control"  id="major_subject" name="major_subject" value="" placeholder="Major Subject">
                        </div>

                        <div class="form-group">
                            <label>Grade</label>
                            <input type="text" class="form-control"  id="grade" name="grade" value="" placeholder="Grade">
                        </div>

                        <div class="form-group">
                            <label>Institute</label>
                            <input type="text" class="form-control"  id="institute" name="institute" value="" placeholder="Institute">
                        </div>

                        <div class="form-group">
                            <label>Country</label>
                            <select name="edu_country" id="edu_country" class="form-control">
                                <?php include 'countries.php'; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control"  id="edu_city" name="edu_city" value="" placeholder="City">
                        </div>

                        <div class="form-group">
                            <label>Completion Year</label>
                            <select class="form-control" name="completion_year" id="completion_year" >
                                <option value="" selected="selected">Select Year</option>
                                <?php for($cyear=date("Y")+6; $cyear>=1950; $cyear--):?>
                                    <option value="<?php echo $cyear;?>"><?php echo $cyear;?></option>
                                <?php endfor;?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_education_submitter" id="js_education_submitter" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends add Jobseeker Education -->
<!-- Starts edit Jobseeker Education-->
<div class="modal fade" id="edit_education_modal">
    <div class="modal-dialog">

        <form name="frm_edit_education" id="frm_edit_education" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Education Information</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_edit_edu"></div>
                        <div class="form-group">
                            <label>Degree Title</label>
                            <select name="ed_degree_title" id="ed_degree_title" class="form-control">
                                <?php foreach($result_degrees as $row_degree): ?>
                                    <option value="<?php echo $row_degree->val;?>"><?php echo $row_degree->text;?></option>
                                <?php endforeach;?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Major Subject</label>
                            <input type="text" class="form-control"  id="ed_major_subject" name="ed_major_subject" value="" placeholder="Major Subject">
                        </div>

                        <div class="form-group">
                            <label>Grade</label>
                            <input type="text" class="form-control"  id="ed_grade" name="ed_grade" value="" placeholder="Grade">
                        </div>

                        <div class="form-group">
                            <label>Institute</label>
                            <input type="text" class="form-control"  id="ed_institute" name="ed_institute" value="" placeholder="Institute">
                        </div>

                        <div class="form-group">
                            <label>Country</label>
                            <select name="ed_edu_country" id="ed_edu_country" class="form-control">
                                <?php include 'countries.php'; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control"  id="ed_edu_city" name="ed_edu_city" value="" placeholder="City">
                        </div>

                        <div class="form-group">
                            <label>Completion Year</label>
                            <select class="form-control" name="ed_completion_year" id="ed_completion_year" >
                                <option value="" selected="selected">Select Year</option>
                                <?php for($cyear=date("Y")+6; $cyear>=1950; $cyear--):?>
                                    <option value="<?php echo $cyear;?>"><?php echo $cyear;?></option>
                                <?php endfor;?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="ed_edu_id" name="ed_edu_id" value="" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_edit_edu_submit" id="js_edit_edu_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends edit Jobseeker Education -->

<div class="modal fade" id="add_training_modal">
    <div class="modal-dialog">

        <form name="frm_add_training" id="frm_add_training" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Training</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_add_training"></div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control"  id="training_title" name="training_title" value="" placeholder="Title">
                        </div>

                        <div class="form-group">
                            <label>Institute</label>
                            <input type="text" class="form-control"  id="training_institute" name="training_institute" value="" placeholder="institute">
                        </div>

                        <div class="form-group">
                            <label>Training Year</label>
                            <input type="text" class="form-control"  id="training_year" name="training_year" value="" placeholder="Training Year">
                        </div>

                        <div class="form-group">
                            <label>Duration</label>
                            <input type="text" class="form-control"  id="training_duration" name="training_duration" value="" placeholder="Duration">
                        </div>

                        <div class="form-group">
                            <label>Location</label>
                            <input type="text" class="form-control"  id="training_location" name="training_location" value="" placeholder="Location">
                        </div>

                        <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control"  id="training_city" name="training_city" value="" placeholder="City">
                        </div>

                        <div class="form-group">
                            <label>Country</label>
                            <select class="form-control" name="training_country" id="training_country">
                                <?php include 'countries.php' ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Topic Covered</label>
                            <textarea class="form-control" id="training_topic_covered" name="training_topic_covered" rows="3" placeholder="Topic Covered"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_add_training_submit" id="js_add_training_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="edit_training_modal">
    <div class="modal-dialog">

        <form name="frm_edit_training" id="frm_edit_training" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Training</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_edit_training"></div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control"  id="ed_training_title" name="ed_training_title" value="" placeholder="Title">
                        </div>

                        <div class="form-group">
                            <label>Institute</label>
                            <input type="text" class="form-control"  id="ed_training_institute" name="ed_training_institute" value="" placeholder="institute">
                        </div>

                        <div class="form-group">
                            <label>Training Year</label>
                            <input type="text" class="form-control"  id="ed_training_year" name="ed_training_year" value="" placeholder="Training Year">
                        </div>

                        <div class="form-group">
                            <label>Duration</label>
                            <input type="text" class="form-control"  id="ed_training_duration" name="ed_training_duration" value="" placeholder="Duration">
                        </div>

                        <div class="form-group">
                            <label>Location</label>
                            <input type="text" class="form-control"  id="ed_training_location" name="ed_training_location" value="" placeholder="Location">
                        </div>

                        <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control"  id="ed_training_city" name="ed_training_city" value="" placeholder="City">
                        </div>

                        <div class="form-group">
                            <label>Country</label>
                            <select class="form-control" name="ed_training_country" id="ed_training_country">
                                <?php include 'countries.php' ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Topic Covered</label>
                            <textarea class="form-control" id="ed_training_topic_covered" name="ed_training_topic_covered" rows="3" placeholder="Topic Covered"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="ed_training_id" id="ed_training_id" value="" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_edit_training_submit" id="js_edit_training_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Starts add Jobseeker Experience-->
<div class="modal fade" id="add_exp_modal">
    <div class="modal-dialog">

        <form name="frm_add_exp" id="frm_add_exp" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Experience Information</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_add_exp"></div>
                        <div class="form-group">
                            <label>Job Title</label>
                            <input type="text" class="form-control"  id="job_title" name="job_title" value="" placeholder="Job Title">
                        </div>

                        <div class="form-group">
                            <label>Company Name</label>
                            <input type="text" class="form-control"  id="company_name" name="company_name" value="" placeholder="Company Name">
                        </div>

                        <div class="form-group">
                            <label>Company Business</label>
                            <input type="text" class="form-control"  id="company_business" name="company_business" value="" placeholder="Company Business">
                        </div>

                        <div class="form-group">
                            <label>Responsibilities</label>
                            <input type="text" class="form-control"  id="responsibilities" name="responsibilities" value="" placeholder="Responsibilities">
                        </div>

                        <div class="form-group">
                            <label>Department</label>
                            <input type="text" class="form-control"  id="department" name="department" value="" placeholder="Department">
                        </div>

                        <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control"  id="exp_city" name="exp_city" value="" placeholder="City">
                        </div>

                        <div class="form-group">
                            <label>Country</label>

                            <select name="exp_country" id="exp_country" class="form-control">
                                <?php include 'countries.php'; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="text" class="form-control" readonly="readonly"  id="start_date" name="start_date" value="" placeholder="Start Date" />
                        </div>

                        <div class="form-group">
                            <label>End Date</label> (Keep blank if still working)
                            <input type="text" class="form-control" id="end_date" name="end_date" value="Present" placeholder="Present" />
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_exp_submit" id="js_exp_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends add Jobseeker Experience -->
<!-- Starts edit Jobseeker Experience-->
<div class="modal fade" id="edit_exp_modal">
    <div class="modal-dialog">

        <form name="frm_edit_exp" id="frm_edit_exp" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Experience Information</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_edit_exp"></div>
                        <div class="form-group">
                            <label>Job Title</label>
                            <input type="text" class="form-control"  id="ed_job_title" name="ed_job_title" value="" placeholder="Job Title">
                        </div>

                        <div class="form-group">
                            <label>Company Name</label>
                            <input type="text" class="form-control"  id="ed_company_name" name="ed_company_name" value="" placeholder="Company Name">
                        </div>

                        <div class="form-group">
                            <label>Company Business</label>
                            <input type="text" class="form-control"  id="ed_company_business" name="ed_company_business" value="" placeholder="Company Business">
                        </div>

                        <div class="form-group">
                            <label>Responsibilities</label>
                            <input type="text" class="form-control"  id="ed_responsibilities" name="ed_responsibilities" value="" placeholder="Responsibilities">
                        </div>

                        <div class="form-group">
                            <label>Department</label>
                            <input type="text" class="form-control"  id="ed_department" name="ed_department" value="" placeholder="Department">
                        </div>

                        <div class="form-group">
                            <label>Country</label>
                            <select name="ed_exp_country" id="ed_exp_country" class="form-control">
                                <?php include 'countries.php'; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>City</label>
                            <input type="text" class="form-control"  id="ed_exp_city" name="ed_exp_city" value="" placeholder="City">
                        </div>

                        <div class="form-group">
                            <label>Start Date</label>
                            <input type="text" class="form-control" readonly="readonly"  id="ed_start_date" name="ed_start_date" value="" placeholder="Start Date" />
                        </div>

                        <div class="form-group">
                            <label>End Date</label> (Keep blank if still working)
                            <input type="text" class="form-control" id="ed_end_date" name="ed_end_date" value="Present" placeholder="Present" />
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="ed_exp_id" id="ed_exp_id" value="" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_edit_exp_submit" id="js_edit_exp_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends edit Jobseeker Experience -->

<!-- Starts add Language Proficiency-->
<div class="modal fade" id="add_language_modal">
    <div class="modal-dialog">

        <form name="frm_add_language" id="frm_add_language" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Language Proficiency</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_add_language"></div>
                        <div class="form-group">
                            <label>Language</label>
                            <input type="text" class="form-control"  id="language" name="language" value="" placeholder="Language Name">
                        </div>
                        <div class="form-group">
                            <label>Writing</label>
                            <select name="writing" id="writing" class="form-control">
                                <option value="Low">Low</option>
                                <option value="Midium">Midium</option>
                                <option value="High">High</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Reading</label>
                            <select name="reading" id="reading" class="form-control">
                                <option value="Low">Low</option>
                                <option value="Midium">Midium</option>
                                <option value="High">High</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Speaking</label>
                            <select name="speaking" id="speaking" class="form-control">
                                <option value="Low">Low</option>
                                <option value="Midium">Midium</option>
                                <option value="High">High</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_language_submit" id="js_language_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends edit Language Proficiency -->

<!-- Starts edit Language Proficiency-->
<div class="modal fade" id="edit_language_modal">
    <div class="modal-dialog">

        <form name="frm_edit_language" id="frm_edit_language" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Language Proficiency</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_edit_language"></div>
                        <div class="form-group">
                            <label>Language</label>
                            <input type="text" class="form-control"  id="ed_language" name="ed_language" value="" placeholder="Language Name">
                        </div>
                        <div class="form-group">
                            <label>Writing</label>
                            <select name="ed_writing" id="ed_writing" class="form-control">
                                <option value="Low">Low</option>
                                <option value="Midium">Midium</option>
                                <option value="High">High</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Reading</label>
                            <select name="ed_reading" id="ed_reading" class="form-control">
                                <option value="Low">Low</option>
                                <option value="Midium">Midium</option>
                                <option value="High">High</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Speaking</label>
                            <select name="ed_speaking" id="ed_speaking" class="form-control">
                                <option value="Low">Low</option>
                                <option value="Midium">Midium</option>
                                <option value="High">High</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="ed_language_id" id="ed_language_id" value="" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_edit_language_submit" id="js_edit_language_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Ends edit Language Proficiency -->

<div class="modal fade" id="add_reference_modal">
    <div class="modal-dialog">

        <form name="frm_edit_reference" id="frm_add_reference" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Reference</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_add_reference"></div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control"  id="reference_name" name="reference_name" value="" placeholder="Name">
                        </div>

                        <div class="form-group">
                            <label>Designation</label>
                            <input type="text" class="form-control"  id="reference_designation" name="reference_designation" value="" placeholder="Designation">
                        </div>

                        <div class="form-group">
                            <label>Mobile</label>
                            <input type="text" class="form-control"  id="reference_mobile" name="reference_mobile" value="" placeholder="Mobile Number">
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control"  id="reference_email" name="reference_email" value="" placeholder="Email">
                        </div>

                        <div class="form-group">
                            <label>Relation</label>
                            <select class="form-control" name="reference_relation" id="reference_relation">
                                <option value="Relative">Relative</option>
                                <option value="Family Friend">Family Friend</option>
                                <option value="Academic">Academic</option>
                                <option value="Professional">Professional</option>
                                <option value="Others">Others</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Organaization</label>
                            <input type="text" class="form-control"  id="reference_organaization" name="reference_organaization" value="" placeholder="Name">
                        </div>

                        <div class="form-group">
                            <label>Office Phone</label>
                            <input type="text" class="form-control"  id="reference_phone" name="reference_phone" value="" placeholder="Phone" />
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea class="form-control" id="reference_address" name="reference_address" rows="3" placeholder="Address"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_add_reference_submit" id="js_add_reference_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="edit_reference_modal">
    <div class="modal-dialog">

        <form name="frm_edit_reference" id="frm_edit_reference" role="form" method="post" action="<?php echo base_url('');?>">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">reference - 1</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                        <div id="emsg_edit_reference"></div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control"  id="ed_reference_name" name="ed_reference_name" value="" placeholder="Name">
                        </div>

                        <div class="form-group">
                            <label>Designation</label>
                            <input type="text" class="form-control"  id="ed_reference_designation" name="ed_reference_designation" value="" placeholder="Designation">
                        </div>

                        <div class="form-group">
                            <label>Mobile</label>
                            <input type="text" class="form-control"  id="ed_reference_mobile" name="ed_reference_mobile" value="" placeholder="Mobile Number">
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control"  id="ed_reference_email" name="ed_reference_email" value="" placeholder="Email">
                        </div>

                        <div class="form-group">
                            <label>Relation</label>
                            <select class="form-control" name="ed_reference_relation" id="ed_reference_relation">
                                <option value="Relative">Relative</option>
                                <option value="Family Friend">Family Friend</option>
                                <option value="Academic">Academic</option>
                                <option value="Professional">Professional</option>
                                <option value="Others">Others</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Organaization</label>
                            <input type="text" class="form-control"  id="ed_reference_organaization" name="ed_reference_organaization" value="" placeholder="Name">
                        </div>

                        <div class="form-group">
                            <label>Office Phone</label>
                            <input type="text" class="form-control"  id="ed_reference_phone" name="ed_reference_phone" value="" placeholder="Phone" />
                        </div>
                        <div class="form-group">
                            <label>Address</label>
                            <textarea class="form-control" id="ed_reference_address" name="ed_reference_address" rows="3" placeholder="Address"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="ed_reference_id" id="ed_reference_id" value="" />
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" name="js_edit_reference_submit" id="js_edit_reference_submit" class="btn btn-primary">Update</button>
                </div>
            </div>
        </form>
    </div>
</div>
