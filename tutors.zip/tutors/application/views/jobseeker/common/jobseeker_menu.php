<ul class="featurlist">
    <li><a href="<?php echo base_url('jobseeker/dashboard');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'dashboard');?>"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
    <li><a href="<?php echo base_url('jobseeker/my_account');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'my_account');?>"><i class="fa fa-user"></i> <span>Manage Account</span></a></li>
    <li><a href="<?php echo base_url('jobseeker/view_resume');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'view_resume');?>"><i class="fa fa-eye"></i> <span>View Resume</span></a></li>
    <li><a href="<?php echo base_url('jobseeker/edit_resume');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'edit_resume');?> <?php echo is_active_like($this->uri->segment(2),'cv_builder');?>"><i class="fa fa-edit"></i> <span>Edit Resume</span></a></li>
    <li><a href="<?php echo base_url('jobseeker/my_jobs');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'my_jobs');?>"><i class="fa fa-globe"></i> <span>Online Applications</span></a></li>
    <li><a href="<?php echo base_url('jobseeker/matching_jobs');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'matching_jobs');?>"><i class="fa fa-briefcase"></i> <span>Job Matching</span></a></li>
    <li><a href="<?php echo base_url('jobseeker/add_skills');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'add_skills');?>"><i class="fa fa-gears"></i> <span>Manage Skills</span></a></li>
    <li><a href="<?php echo base_url('jobseeker/change_password');?>" class="innerfetbox <?php echo is_active_like($this->uri->segment(2),'change_password');?>"><i class="fa fa-lock"></i> <span>Change Password</span></a></li>
    <div class="clear"></div>
</ul>
