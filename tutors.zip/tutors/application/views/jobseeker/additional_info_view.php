<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('common/meta_tags'); ?>
    <title><?php echo $title;?></title>
    <?php $this->load->view('common/before_head_close'); ?>
</head>
<body>
    <?php $this->load->view('common/after_body_open'); ?>
    <div class="siteWraper">
        <!--Header-->
        <?php $this->load->view('common/header'); ?>
        <!--/Header-->
        <div class="container detailinfo">
            <div class="row">
                <div class="col-md-3">
                    <div class="dashiconwrp">
                        <?php $this->load->view('jobseeker/common/jobseeker_menu'); ?>
                    </div>
                </div>

                <div class="col-md-9">
                    <?php echo $this->session->flashdata('msg');?>
                    <!--Personal info-->
                    <div class="formwraper">
                        <div class="titlehead">Additional Information</div>
                        <?php echo form_open_multipart('jobseeker/additional_info',array('name' => 'additional_form', 'id' => 'additional_form', 'onSubmit' => 'return validate_additional_form(this);'));?>
                        <div class="formint">
                            <div class="input-group <?php echo (form_error('interest'))?'has-error':'';?>">
                                <label class="input-group-addon">Interest</label>
                                <textarea name="interest" id="interest" class="form-control" rows="3"><?php echo @$row->interest; ?></textarea>
                                <?php echo form_error('interest'); ?>
                            </div>

                            <div class="input-group <?php echo (form_error('awards'))?'has-error':'';?>">
                                <label class="input-group-addon">Achievements</label>
                                <textarea name="awards" id="awards" class="form-control" rows="3"><?php echo @$row->awards; ?></textarea>
                                <?php echo form_error('awards'); ?>
                            </div>

                            <div class="input-group <?php echo (form_error('summary'))?'has-error':'';?>">
                                <label class="input-group-addon">Professional summary</label>
                                <textarea name="summary" id="summary" class="form-control" rows="4"><?php echo @$row->summary; ?></textarea>
                                <?php echo form_error('summary'); ?>
                            </div>

                            <div class="input-group">
                                <label class="input-group-addon">&nbsp;</label>
                                <input type="submit" name="js_additional_submit" id="js_additional_submit" value="Update" class="btn btn-primary" />
                            </div>
                        </div>
                        <?php echo form_close();?>
                    </div>
                </div>
                <!--/Job Detail-->
            </div>
        </div>
        <?php $this->load->view('common/bottom_ads');?>
        <!--Footer-->
        <?php $this->load->view('common/footer'); ?>
        <?php $this->load->view('common/before_body_close'); ?>
        <script src="<?php echo base_url('public/js/validate_jobseeker.js');?>" type="text/javascript"></script>
    </body>
    </html>
