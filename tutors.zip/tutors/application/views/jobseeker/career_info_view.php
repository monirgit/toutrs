<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('common/meta_tags'); ?>
    <title><?php echo $title;?></title>
    <?php $this->load->view('common/before_head_close'); ?>
</head>
<body>
    <?php $this->load->view('common/after_body_open'); ?>
    <div class="siteWraper">
        <!--Header-->
        <?php $this->load->view('common/header'); ?>
        <!--/Header-->
        <div class="container detailinfo">
            <div class="row">
                <div class="col-md-3">
                    <div class="dashiconwrp">
                        <?php $this->load->view('jobseeker/common/jobseeker_menu'); ?>
                    </div>
                </div>

                <div class="col-md-9">
                    <?php echo $this->session->flashdata('msg');?>
                    <!--Personal info-->
                    <div class="formwraper">
                        <div class="titlehead">Additional Information</div>
                        <?php echo form_open_multipart('jobseeker/career_info',array('name' => 'career_form', 'id' => 'career_form', 'onSubmit' => 'return validate_career_form(this);'));?>
                        <div class="formint">

                            <div class="input-group <?php echo (form_error('description'))?'has-error':'';?>">
                                <label class="input-group-addon">Career Objective <span>*</span></label>
                                <textarea name="description" id="description" class="form-control" rows="4"><?php echo @$row->description; ?></textarea>
                                <?php echo form_error('description'); ?>
                            </div>

                            <div class="input-group <?php echo (form_error('salary'))?'has-error':'';?>">
                                <label class="input-group-addon">Present Salary </label>
                                <input type="text" name="salary" id="salary" class="form-control" value="<?php echo @$row->salary; ?>">
                                <?php echo form_error('salary'); ?>
                            </div>

                            <div class="input-group <?php echo (form_error('expected_salary'))?'has-error':'';?>">
                                <label class="input-group-addon">Expected Salary </label>
                                <input type="text" name="expected_salary" id="expected_salary" class="form-control" value="<?php echo @$row->expected_salary; ?>">
                                <?php echo form_error('expected_salary'); ?>
                            </div>

                            <div class="input-group <?php echo (form_error('job_level'))?'has-error':'';?>">
                                <label class="input-group-addon">Looking For (Job Level) </label>
                                <select name="job_level" id="job_level" class="form-control">
                                    <option value="Entry Level">Entry Level</option>
                                    <option value="Mid Level" <?php echo (@$row->job_level == "Mid Level") ? "selected='selected'" : ""; ?>>Mid Level</option>
                                    <option value="Top Level" <?php echo (@$row->job_level == "Top Level") ? "selected='selected'" : ""; ?>>Top Level</option>
                                </select>
                                <?php echo form_error('job_level'); ?>
                            </div>

                            <div class="input-group <?php echo (form_error('job_nature'))?'has-error':'';?>">
                                <label class="input-group-addon">Available For (Job Nature) </label>
                                <select name="job_nature" id="job_nature" class="form-control">
                                    <option value="Full Time">Full Time</option>
                                    <option value="Part Time" <?php echo (@$row->job_nature == "Part Time") ? "selected='selected'" : ""; ?>>Part Time</option>
                                    <option value="Contract" <?php echo (@$row->job_nature == "Contract") ? "selected='selected'" : ""; ?>>Contract</option>
                                </select>
                                <?php echo form_error('job_nature'); ?>
                            </div>

                            <div class="input-group">
                                <label class="input-group-addon">&nbsp;</label>
                                <input type="submit" name="js_additional_submit" id="js_additional_submit" value="Update" class="btn btn-primary" />
                            </div>
                        </div>
                        <?php echo form_close();?>
                    </div>
                </div>
                <!--/Job Detail-->
            </div>
        </div>
        <?php $this->load->view('common/bottom_ads');?>
        <!--Footer-->
        <?php $this->load->view('common/footer'); ?>
        <?php $this->load->view('common/before_body_close'); ?>
        <script src="<?php echo base_url('public/js/validate_jobseeker.js');?>" type="text/javascript"></script>
    </body>
    </html>
