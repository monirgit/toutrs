<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title><?php echo $title;?></title>
	<?php $this->load->view('admin/common/meta_tags'); ?>
	<?php $this->load->view('admin/common/before_head_close'); ?>
	<style type="text/css">
	.awesome_style {
		font-size:50px;
	}
	</style>
</head>
<body class="skin-blue">
	<?php $this->load->view('admin/common/after_body_open'); ?>
	<?php $this->load->view('admin/common/header'); ?>
	<div class="wrapper row-offcanvas row-offcanvas-left">
		<?php $this->load->view('admin/common/left_side'); ?>
		<!-- Right side column. Contains the navbar and content of the page -->
		<aside class="right-side">
			<!-- Content Header (Page header) -->
			<section class="content-header">
				<h1> Dashboard</h1></section>


				<section class="content">
					<div class="display-flex">
						<div class="item">
							<a href="<?php echo base_url('admin/employers');?>"> <i class="fa awesome_style fa-briefcase"></i> Employers </a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/job_seekers');?>"><i class="fa awesome_style awesome_style fa-user"></i>Jobseeker</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/posted_jobs');?>"><i class="fa awesome_style fa-upload"></i>Posted Jobs</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/posted_jobs');?>"><i class="fa fa-clipboard awesome_style"></i>Featured Jobs</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/pages');?>"><i class="fa awesome_style fa-file-text"></i>Content Management</a>
						</div>

						<!-- <div class="item">
							<a href="<?php echo base_url('admin/stories');?>"><i class="fa awesome_style fa-thumbs-up"></i>Success Stories</a>
						</div> -->
						<div class="item">
							<a href="<?php echo base_url('admin/invite_employer');?>"><i class="fa awesome_style fa-envelope"></i>Invite Employer</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/invite_jobseeker');?>"><i class="fa awesome_style fa-users"></i>Invite Jobseeker</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/email_template');?>"><i class="fa fa-envelope awesome_style"></i>Email Templates</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/ads');?>"><i class="fa awesome_style fa-bullhorn"></i>Ads</a>
						</div>

						<div class="item">
							<a href="<?php echo base_url('admin/industries');?>"><i class="fa fa-desktop awesome_style"></i>Job Industries</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/institute');?>"><i class="fa awesome_style fa-university"></i>Institute</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/salary');?>"><i class="fa awesome_style fa-money"></i>Salary</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/qualification');?>"><i class="fa  awesome_style fa-graduation-cap">&nbsp;</i>Qualification</a>
						</div>
						<!-- <div class="item">
							<a href="<?php echo base_url('admin/prohibited_keyword');?>"><i class="fa awesome_style fa-tags"></i>Manage Prohibited Keywords</a>
						</div> -->

						<div class="item">
							<a href="<?php echo base_url('admin/skills');?>"><i class="fa awesome_style fa-tags"></i>Manage Skills</a>
						</div>
						<div class="item">
							<a href="<?php echo base_url('admin/manage_newsletters');?>"><i class="fa fa-envelope awesome_style"></i>Manage Newsletters</a>
						</div>
						<!-- <div class="item">
							<a href="<?php echo base_url('admin/job_alert_queue');?>"><i class="fa fa-envelope awesome_style"></i>Job Alert Queue</a>
						</div> -->
					</div>
				</section>

				<!-- Main content -->
			</section>
			<!-- /.content -->
		</aside>
		<!-- /.right-side -->
		<?php $this->load->view('admin/common/footer'); ?>
