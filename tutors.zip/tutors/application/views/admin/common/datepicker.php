<link rel="stylesheet" href="<?php echo base_url('public/datepicker/css/datepicker.css');?>" type="text/css" />
<link rel="stylesheet" media="screen" type="text/css" href="<?php echo base_url('public/datepicker/css/layout.css');?>" />
<script type="text/javascript" src="<?php echo base_url('public/datepicker/js/jquery.js');?>"></script>  
<script type="text/javascript" src="<?php echo base_url('public/datepicker/js/datepicker.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('public/datepicker/js/eye.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('public/datepicker/js/utils.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('public/datepicker/js/layout.js?ver=1.0.2');?>"></script>
