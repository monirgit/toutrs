<div class="right-div">
      <div class="heading">
        <div><img src="<?php echo base_url(); ?>public/images/main_images/youvip-heading.png" width="293" height="99" style="display:block;" /></div>
        <div> <img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-1.png" width="293" height="283" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-2.png" width="293" height="62" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-3.png" width="293" height="79" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-4.png" width="293" height="65" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-5.png" width="293" height="130" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-6.png" width="293" height="57" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-7.png" width="293" height="110" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-8.png" width="293" height="79" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-9.png" width="293" height="79" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-10.png" width="293" height="72" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-11.png" width="293" height="72" /></div>
        <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-12.png" width="293" height="105" /></div>
         <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-13.png" width="293" height="70" /></div>
          <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-14.png" width="293" height="70" /></div>
           <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-15.png" width="293" height="109" /></div>
           <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-16.png" width="293" height="96" /></div>
           <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-17.png" width="293" height="66" /></div>
           <div><img src="<?php echo base_url(); ?>public/images/main_images/yourchoice-18.png" width="293" height="126" /></div>
      </div>
    </div>