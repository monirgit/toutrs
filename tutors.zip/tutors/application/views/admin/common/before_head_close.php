<link href="<?php echo base_url('public/css/admin/css/bootstrap.min.css');?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('public/css/admin/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('public/css/admin/css/ionicons.min.css'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('public/css/admin/css/datatables/dataTables.bootstrap.css'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('public/css/admin/css/AdminLTE.css'); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url('public/css/admin/admin_dev_style.css'); ?>" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php echo base_url('public/images/favicon.ico'); ?>">
<script>var baseUrl = '<?php echo base_url();?>';</script>
