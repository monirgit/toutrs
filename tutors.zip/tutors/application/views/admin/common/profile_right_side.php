<div class="rightCol right">
            <div class="recomendWrap">
            	<h1>Friends Near By You</h1>
            	<ul class="recomendList">
                	<li>
                    	<div class="imgbox"><img src="<?php echo base_url(); ?>glancePublic/images/img6.jpg" alt="" /></div>
                        <div class="infoProfile">
                        	<h2><a href="#" title="Janifer">Janifer</a></h2>
                            <p>Female</p>
                            <p>Dhaka, Bangladesh</p>
                            <a href="#" class="chatbtn" title="Send Friend Request">Add Friend</a> <a href="#" class="chatbtn" title="Send Message">Message</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </li>

                    <li>
                    	<div class="imgbox"><img src="<?php echo base_url(); ?>glancePublic/images/img6.jpg" alt="" /></div>
                        <div class="infoProfile">
                        	<h2><a href="#" title="Janifer">Janifer</a></h2>
                            <p>Female</p>
                            <p>Dhaka, Bangladesh</p>
                            <a href="#" class="chatbtn" title="Send Friend Request">Add Friend</a> <a href="#" class="chatbtn" title="Send Message">Message</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </li>

                    <li>
                    	<div class="imgbox"><img src="<?php echo base_url(); ?>glancePublic/images/img6.jpg" alt="" /></div>
                        <div class="infoProfile">
                        	<h2><a href="#" title="Janifer">Janifer</a></h2>
                            <p>Female</p>
                            <p>Dhaka, Bangladesh</p>
                            <a href="#" class="chatbtn" title="Send Friend Request">Add Friend</a> <a href="#" class="chatbtn" title="Send Message">Message</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </li>

                </ul>
            </div>

            <div class="banner250"><h6>Sponsord Links</h6><img src="<?php echo base_url(); ?>glancePublic/images/banner250.jpg" /></div>

       </div>
