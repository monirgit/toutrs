<div class="footerWrap">
    <div class="container">
        <div class="col-md-3">
            <img src="<?php echo base_url('public/images/logo-white.png');?>" alt="Bangladesh jobs website" />
            <br><br>
            <p></p>

            <!--Social-->

            <div class="social">
                <a href="http://www.facebook.com" target="_blank"> <i class="fa fa-2x fa-facebook" aria-hidden="true"></i></a>
                <a href="https://www.linkedin.com" target="_blank"><i class="fa fa-2x fa-linkedin" aria-hidden="true"></i></a>
                <a href="http://www.twitter.com" target="_blank"><i class="fa fa-2x fa-twitter" aria-hidden="true"></i></a>
                <a href="http://www.plus.google.com" target="_blank"><i class="fa fa-2x fa-google-plus" aria-hidden="true"></i></a>
            </div>
            <br>

            <div>
                <p align="center"><font color="white"><b>Hotline</b> (10am to 6pm) : </font></p>

                <p align="center"><font color="white">017 8008 6417, 017 6488 1939  </font></p>

                <p align="center"><a align="center" href="#" target="_blank"> <i class="fa fa-envelope" aria-hidden="true"></i> info@bdjobbank.com</a></p>
            </div>
        </div>
        <div class="col-md-2">
            <h5 class="title">Quick Links</h5>
            <div class="title-line"></div>
            <ul class="quicklinks">
                <li><a href="<?php echo base_url('about-us.html');?>" title="About Us">About Us</a></li>
                <li><a href="<?php echo base_url('how-to-get-job.html');?>" title="How to get Job">How to get Job</a></li>
                <li><a href="<?php echo base_url('search-jobs');?>" title="New Job Openings">New Job Openings</a></li>
                <li><a href="<?php echo base_url('contact-us');?>" title="Contact Us">Contact Us</a></li>
                <li><a href="<?php echo base_url('interview.html');?>" title="Preparing for Interview">Preparing for Interview</a>
                </li>
                <li><a href="<?php echo base_url('cv-writing.html');?>" title="CV Writing">CV Writing</a></li>
                <li><a href="<?php echo base_url('privacy-policy.html');?>" title="Policy">Policy</a></li>
            </ul>
        </div>

        <div class="col-md-3">
            <h5 class="title">Popular Industries</h5>
            <div class="title-line"></div>
            <ul class="quicklinks">
                <?php
                $res_inds = $this->industries_model->get_top_industries();
                if($res_inds):
                    foreach($res_inds as $row_inds):
                        ?>
                        <li><a href="<?php echo base_url('industry/'.$row_inds->slug);?>" title="<?php echo $row_inds->industry_name;?> Jobs"><?php echo $row_inds->industry_name;?> Jobs</a></li>
                        <?php
                    endforeach;
                endif;
                ?>
            </ul>
        </div>
        <div class="col-md-4">
            <h5 class="title">Popular Cities</h5>
            <div class="title-line"></div>
            <ul class="citiesList">
                <li><a class="muted" href="<?php echo base_url('search/dhaka');?>" title="Jobs in Dhaka">Dhaka</a></li>
                <li><a class="muted" href="<?php echo base_url('search/chittagong');?>" title="Jobs in Chittagong">Chittagong</a></li>
                <li><a class="muted" href="<?php echo base_url('search/sylhet');?>" title="Jobs in Sylhet">Sylhet</a></li>
                <li><a class="muted" href="<?php echo base_url('search/rajshahi');?>" title="Jobs in Rajshahi">Rajshahi</a></li>
                <li><a class="muted" href="<?php echo base_url('search/rangpur');?>" title="Jobs in Rangpur">Rangpur</a></li>
                <li><a class="muted" href="<?php echo base_url('search/mymensingh');?>" title="Jobs in Khulna">Khulna</a></li>
                <li><a class="muted" href="<?php echo base_url('search/austin');?>" title="Jobs in Mymensingh">Mymensingh</a></li>
                <li><a class="muted" href="<?php echo base_url('search/barisal');?>" title="Jobs in Barisal">Barisal</a></li>
            </ul>
            <div class="clear"></div>
        </div>

        <div class="clear"></div>
        <div class="copyright">
    
            <div class="bttxt">Copyright <?php echo date('Y');?> <a href="bdjobbank.com">BDJOBBank.com</a>, AxisPro Technology Ltd.
            Developed and maintain by <a href="http://datacraftbd.com" target="_blank">Datacraft</a></div>
        </div>
    </div>
</div>
</div>
<?php echo $ads_row->google_analytics;?>
