<?php
if($this->session->userdata('is_user_login')!=TRUE) {
    ?>
    <div class="candidatesection">
        <div class="col-sm-12">
            <h1>Find the right job.<span> Right now.</span></h1>
        </div>
        <div class="col-sm-12">
            <div class="search-content">
                <?php echo form_open_multipart('job_search/search',array('name' => 'jsearch', 'id' => 'jsearch'));?>
                <div class="row">
                    <div class="col-md-5 col-sm-5">
                        <label for="job_params">What</label>
                        <input type="text" required name="job_params" id="job_params" class="form-control" placeholder="Job title or Skill" />
                    </div>
                    <div class="col-md-5 col-sm-5 col-xs-12">
                        <label for="jcity">Where</label>
                        <select class="form-control" name="jcity" id="jcity">
                        
                            <option value="" selected>Select Cities</option>

                            <?php 
                            if($cities_res): foreach($cities_res as $cities):?>
                                <option value="<?php echo $cities->city_name;?>"><?php echo $cities->city_name;?>
                                </option>
                            <?php endforeach;
                             endif;?>
                        </select>
                    </div>

                    <div class="col-md-2 col-sm-2">
                        <label>&nbsp;</label>
                        <button type="submit" name="job_submit" class="btn btn-block" id="job_submit"> Search Jobs </button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="divisions">
                            <h4>Divisional Jobs</h4>
                            <ul>
                                <li><a href="<?= base_url('search/dhaka') ?>">Dhaka</a></li>
                                <li><a href="<?= base_url('search/chittagong') ?>">Chittagong</a></li>
                                <li><a href="<?= base_url('search/rajshahi') ?>">Rajshahi</a></li>
                                <li><a href="<?= base_url('search/khulna') ?>">Khulna</a></li>
                                <li><a href="<?= base_url('search/sylhet') ?>">Sylhet</a></li>
                                <li><a href="<?= base_url('search/rangpur') ?>">Rangpur</a></li>
                                <li><a href="<?= base_url('search/mymensingh') ?>">Mymensingh</a></li>
                                <li><a href="<?= base_url('search/barisal') ?>">Barisal</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php echo form_close();?>
            </div>
        </div>
    </div>
    <?php
} else {
    if($this->session->userdata('is_employer')==TRUE) {
        ?>
        <div class="candidatesection">
            <?php echo form_open_multipart('resume_search/search',array('name' => 'rsearch', 'id' => 'rsearch'));?>
            <div class="col-md-10">
                <div class="row">
                    <div class="col-sm-offset-2 col-sm-10 col-xs-offset-2 col-xs-10  no-padding">
                        <h1>Search Resume</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-offset-2 col-md-8 no-padding">
                        <input type="text" name="resume_params" class="form-control" id="resume_params" placeholder="Search Resume with Skill or Job Title" />
                    </div>
                    <div class="col-md-2 no-padding">
                        <button type="submit" name="resume_submit" class="btn btn-block" id="resume_submit"> Find <i class="fa fa-paper-plane" aria-hidden="true"></i> </button>
                    </div>
                </div>
            </div>
            <?php echo form_close();?>
            <div class="clear"></div>
        </div>
        <?php
    } else {
        ?>
        <div class="candidatesection">
            <div class="col-sm-12">
                <h1>Search a <span> Job.</span></h1>
            </div>
            <div class="col-sm-12">
                <div class="search-content">
                    <?php echo form_open_multipart('job_search/search',array('name' => 'jsearch', 'id' => 'jsearch'));?>
                    <div class="row">
                        <div class="col-md-5 col-sm-5">
                            <label for="job_params">What</label>
                            <input type="text" required name="job_params" id="job_params" class="form-control" placeholder="Job title or Skill" />
                        </div>

                        <div class="col-md-5 col-sm-5">
                            <label for="jcity">Where</label>
                            <select class="form-control" name="jcity" id="jcity">
                                <option value="0">Select Cities</option>
                                <?php if($cities_res): foreach($cities_res as $cities):?>
                                    <option value="<?php echo $cities->city_name;?>"><?php echo $cities->city_name;?></option>
                                <?php endforeach; endif;?>
                            </select>
                        </div>

                        <div class="col-md-2 col-sm-2">
                            <label>&nbsp;</label>
                            <button type="submit" name="job_submit" class="btn btn-block" id="job_submit"> Search Jobs </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="divisions">
                                <h4>Divisional Jobs</h4>
                                <ul>
                                    <li><a href="<?= base_url('search/dhaka') ?>">Dhaka</a></li>
                                    <li><a href="<?= base_url('search/chittagong') ?>">Chittagong</a></li>
                                    <li><a href="<?= base_url('search/rajshahi') ?>">Rajshahi</a></li>
                                    <li><a href="<?= base_url('search/khulna') ?>">Khulna</a></li>
                                    <li><a href="<?= base_url('search/sylhet') ?>">Sylhet</a></li>
                                    <li><a href="<?= base_url('search/rangpur') ?>">Rangpur</a></li>
                                    <li><a href="<?= base_url('search/mymensingh') ?>">Mymensingh</a></li>
                                    <li><a href="<?= base_url('search/barisal') ?>">Barisal</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close();?>
                </div>
            </div>
        </div>
        <?php
    }
}
?>
