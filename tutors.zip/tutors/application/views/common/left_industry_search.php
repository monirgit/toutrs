<div class="col-md-3">
    <div class="secondary">
        <!--Widget-->
        <div class="widget">
            <h4 class="widget-title">Job Categories</h4>
            <ul class="nav nav-pills nav-stacked">
                <?php
                foreach($left_side_industry as $row_industry) {
                    ?>
                    <li class="<?php echo ($row_industry->slug == $row_industry->active) ? 'active' : '' ?>"> <a href="<?php echo base_url('industry/' . $row_industry->slug);?>"><span class="badge pull-right"><?php echo $row_industry->jobs_count; ?></span><?php echo character_limiter($row_industry->industry_name, 20);?></a> </li>
                    <?php
                }
                ?>
            </ul>
        </div>
    </div>
</div>
