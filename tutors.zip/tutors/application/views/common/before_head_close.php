<link href="https://fonts.googleapis.com/css?family=Raleway:400,600,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,600,700,800" rel="stylesheet">
<!-- <link href="http://fonts.googleapis.com/css?family=Lato:400,700,300,400italic&subset=latin" rel="stylesheet"> -->

<link href='<?php echo base_url('public/css/google-fonts.css'); ?>' rel='stylesheet' type='text/css'>
<link href='<?php echo base_url('public/css/flexslider.css'); ?>' rel='stylesheet' type='text/css'>

<!-- Bootstrap -->
<link href="<?php echo base_url('public/css/bootstrap.min.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('public/css/select2.min.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('public/css/font-awesome.css');?>" rel="stylesheet" type="text/css" />

<link href="<?php echo base_url('public/css/style.css?v=1.1.2'); ?>" rel="stylesheet">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="<?php //echo base_url('public/js/html5shiv.js');?>"></script>
      <script src="<?php //echo base_url('public/js/respond.min.js');?>"></script>
    <![endif]-->
<link rel="shortcut icon" href="<?php echo base_url('public/images/favicon.ico'); ?>">
<script>
var baseUrl = '<?php echo base_url();?>';
</script>
