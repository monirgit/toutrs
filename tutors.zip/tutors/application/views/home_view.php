<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('common/meta_tags'); ?>
    <meta name="keywords" content="jobs in Bangladesh, government jobs, online jobs in Bangladesh, latest jobs in Bangladesh,  job in Bangladesh, latest jobs">
    <title><?php echo $title;?></title>
    <?php $this->load->view('common/before_head_close'); ?>
</head>
<body>
    <?php $this->load->view('common/after_body_open'); ?>
    <div class="siteWraper">
        <!--Header-->
        <?php $this->load->view('common/header'); ?>
        <!--/Header-->
        <!--Search Block-->
        <div class="top-colSection">
            <div class="container">
                <div class="row">
                    <?php $this->load->view('common/home_search');?>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
        <!--/Search Block-->

        <!--Category Jobs-->
        <div class="categoriesWrap">
            <div class="container">
                <div class="titlebar">
                    <h2>Jobs By Categories</h2>
                </div>
                <ul class="categoriesList row">
                    <?php
                    foreach ($industries_jobs as $key => $industry){
                        ?>
                        <li class="col-md-3 col-sm-4">
                            <a href="<?php echo base_url('industry/' .$industry->slug) ?>" title="Jobs from <?php echo $industry->industry_name ?>">
                                <?php echo $industry->industry_name ?>
                            </a>
                            <small><?php echo $industry->jobs_count ?></small>
                        </li>
                        <?php
                    }
                    ?>
                </ul>
            </div>
        </div>
        <!--Category Jobs End-->

        <!--Employers-->
        <div class="topemployerwrap">
            <div class="container">
                <div class="titlebar">
                    <h2>Jobs From Top Companies</h2>
                    <!-- <strong>Total - <?php echo $total_employers;?></strong> -->
                </div>
                <ul class="employersList">
                    <?php
                    if($top_employer_result):
                        foreach($top_employer_result as $row_top_employer):
                            $company_logo = ($row_top_employer->company_logo) ? $row_top_employer->company_logo : 'public/images/no-logo.jpg';
                            $company_logo_url = file_exists('public/uploads/employer/thumb/'.$company_logo) ? 'public/uploads/employer/thumb/'.$company_logo : 'public/images/no-logo.jpg';
                            ?>
                            <li>
                                <a href="<?php echo base_url('company/'.$row_top_employer->company_slug);?>" title="Jobs in <?php echo $row_top_employer->company_name;?>">
                                    <span class="logo">
                                        <img src="<?php echo base_url($company_logo_url);?>" alt="<?php echo $row_top_employer->company_name; ?>" />
                                    </span>
                                    <span class="company-name">
                                        <?php echo $row_top_employer->company_name ?>
                                    </span>
                                </a>
                            </li>
                            <?php
                        endforeach;
                    endif;
                    ?>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--Employers Ends-->

        <!--Featured Jobs-->
        <div class="featuredWrap">
            <div class="container">
                <div class="titlebar">
                    <h2>Hot Jobs</h2>
                </div>
                <ul class="featureJobs row">
                    <?php
                    if($featured_job_result):
                        foreach($featured_job_result as $row_hot_job):
                            $job_title = ellipsize(humanize($row_hot_job->job_title),32,1);
                            $company_logo = ($row_hot_job->company_logo) ? $row_hot_job->company_logo : 'public/images/no-logo.jpg';
                            $company_logo_url = file_exists('public/uploads/employer/thumb/'.$company_logo) ? 'public/uploads/employer/thumb/'.$company_logo : 'public/images/no-logo.jpg';
                            ?>
                            <li class="col-md-4 col-sm-6">
                                <div class="intbox">
                                    <div class="row flex">
                                        <div class="col-xs-3">
                                            <a href="<?php echo base_url('company/'.$row_hot_job->company_slug);?>" title="Jobs in <?php echo $row_hot_job->company_name;?>" class="thumbnail">
                                                <img src="<?php echo base_url($company_logo_url);?>" alt="<?php echo $row_hot_job->company_name ?>" />
                                            </a>
                                        </div>
                                        <div class="col-xs-9">
                                            <div class="company">
                                                <a href="<?php echo base_url('company/'.$row_hot_job->company_slug);?>" title="Jobs in <?php echo $row_hot_job->company_name;?>">
                                                    <?php echo $row_hot_job->company_name;?>
                                                </a>
                                            </div>
                                            <a href="<?php echo base_url('jobs/'.$row_hot_job->job_slug);?>" class="jobtitle" title="<?php echo $row_hot_job->job_title;?>">
                                                <?php echo $job_title;?>
                                            </a>
                                            <div class="date">Apply by  <?php echo date_formats($row_hot_job->last_date, 'M d, Y');?> </div>
                                            <div class="clear"></div>
                                        </div>

                                    </div>
                                </div>
                            </li>
                            <?php
                        endforeach;
                    endif;
                    ?>
                </ul>
            </div>
        </div>
        <!--Featured Jobs End-->

        <?php
        if($latest_jobs_result) {
            ?>
            <!--Latest Jobs Block-->
            <div class="latestjobs">
                <div class="container">

                    <div class="titlebar">
                        <h2>Latest Jobs</h2>
                        <!-- <strong>Total - <?php echo $total_posted_jobs;?></strong> -->
                    </div>


                    <ul class="row joblist">
                        <?php
                        foreach($latest_jobs_result as $row_latest_jobs){
                            $job_title = ellipsize(humanize($row_latest_jobs->job_title),32,1);

                            $company_logo = ($row_latest_jobs->company_logo) ? $row_latest_jobs->company_logo : 'public/images/no-logo.jpg';
                            $company_logo_url = file_exists('public/uploads/employer/thumb/'.$company_logo) ? 'public/uploads/employer/thumb/'.$company_logo : 'public/images/no-logo.jpg';
                            ?>
                            <li class="col-md-4 col-sm-6">
                                <div class="job-info">
                                    <div class="intlist">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <div class="row">
                                                    <div class="col-xs-3">
                                                        <a href="<?php echo base_url('company/'.$row_latest_jobs->company_slug);?>" title="Jobs in <?php echo $row_latest_jobs->company_name;?>" class="thumbnail">
                                                            <img src="<?php echo base_url($company_logo_url);?>" alt="<?php echo $row_latest_jobs->company_name; ?>" />
                                                        </a>
                                                    </div>
                                                    <div class="col-xs-9">
                                                        <div class="company">
                                                            <a href="<?php echo base_url('company/'.$row_latest_jobs->company_slug);?>" title="Jobs in <?php echo $row_latest_jobs->company_name;?>">
                                                                <?php echo $row_latest_jobs->company_name;?>
                                                            </a>
                                                        </div>
                                                        <a href="<?php echo base_url('jobs/'.$row_latest_jobs->job_slug);?>" class="jobtitle" title="<?php echo $row_latest_jobs->job_title;?>">
                                                            <?php echo $job_title;?>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clear"></div>
                                            <div class="col-xs-12">
                                                <div class="text-center">
                                                    <div class="appybtn-border"></div>
                                                    <a href="<?php echo base_url('jobs/'.$row_latest_jobs->job_slug.'?apply=yes');?>" class="applybtn" title="<?php echo $row_latest_jobs->industry_name.' Job in '.$row_latest_jobs->city;?>">Apply Now</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <?php
                        }
                        ?>
                    </ul>

                </div>
            </div>
            <!--/Latest Jobs Block-->
            <?php
        }
        ?>
        <!--Cities-->
        <div class="citiesWrap">
            <div class="container">
                <div class="titlebar"><h2>Bangladesh Local Jobs</h2></div>
                <ul class="citiesList row">
                    <?php
                    foreach ($districts as $key => $district) {
                        ?>
                        <li class="col-md-2 col-sm-3 col-xs-6"><a href="<?php echo base_url('search/'.$district);?>" title="Jobs in <?php echo ucfirst($district) ?>">
                        <?php echo ucfirst(str_replace("-", ' ',$district)); ?></a></li>
                        <?php
                    }
                    ?>
                </ul>
            </div>
        </div>
        <!--Cities End-->

    </div>


    <!--Footer-->
    <?php $this->load->view('common/footer'); ?>
    <?php $this->load->view('common/before_body_close'); ?>
    <!-- FlexSlider -->
    <script src="<?php echo base_url('public/js/jquery.flexslider.js');?>" type="text/javascript"></script>
    <script>
    // Can also be used with $(document).ready()
    $(window).load(function() {
        $('.flexslider').flexslider({
            animation: "slide",
            animationLoop: false,
            itemWidth: 250,
            minItems: 1,
            maxItems: 1
        });
        $("#jcity").select2();
    });
    </script>
</body>
</html>
