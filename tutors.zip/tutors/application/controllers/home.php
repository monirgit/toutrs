<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Home extends CI_Controller {

	public function __construct(){
        parent::__construct();
		$this->ads = '';
		$this->ads = $this->ads_model->get_ads();
    }

	public function index()
	{
		$data['ads_row'] = $this->ads;

		$data['title'] = "Jobs and Recruitment on bdjobbank";

		//Latest jobs section
		$latest_jobs_result = $this->posted_jobs_model->get_opened_jobs_home_page(20, 0);
		$total_posted_jobs 	= $this->posted_jobs_model->record_count('pp_post_jobs');

		$industry_row = $this->industries_model->get_all_industries();

		//Categories
		$industries_jobs = [];
		foreach ($industry_row as $key => $industry) {
			$total_rows = $this->posted_jobs_model->count_records_by_industry($industry->ID);
			$industry->jobs_count = $total_rows;
			$industries_jobs[] = $industry;
		}

		//Top employer section
		$top_employer_result= $this->employers_model->get_all_active_top_employers(32, 0);
		$total_employers 	= $this->employers_model->record_count('pp_employers');

		//Feature jobs
		$featured_job_result= $this->posted_jobs_model->get_active_featured_posted_job(10, 0);

		//Cities
		$data['cities_res'] = $this->cities_model->get_all_cities();

		$data['total_posted_jobs'] = $total_posted_jobs;
		$data['latest_jobs_result'] = $latest_jobs_result;
		$data['top_employer_result'] = $top_employer_result;
		$data['total_employers'] = $total_employers;
		$data['featured_job_result'] = $featured_job_result;
		$data['industries_jobs'] = $industries_jobs;
		$data['districts']		= $this->cities_model->get_all_districts();
		$this->load->view('home_view',$data);
	}
}
