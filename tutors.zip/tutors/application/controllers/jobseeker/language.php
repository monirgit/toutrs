<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Language extends CI_Controller {

	public function index(){
		echo "you are not allow to access this page directly";
		exit;
	}

	public function add()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('language', 'language', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('writing', 'writing', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('reading', 'reading', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('speaking', 'speaking', 'trim|required|strip_all_tags');
		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}
		$language_array = array(
			'seeker_ID'		=> $this->session->userdata('user_id'),
			'language'		=> $this->input->post('language'),
			'writing'		=> $this->input->post('writing'),
			'reading' 		=> $this->input->post('reading'),
			'speaking' 		=> $this->input->post('speaking')
		);
		$this->jobseeker_language_model->add($language_array);
		$this->session->set_flashdata('msg', '<div class="alert alert-success"> <a href="#" class="close" data-dismiss="alert">&times;</a> <strong>Success!</strong> Your language has been added successfully. </div>');
		echo "done";
	}

	public function edit()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('language', 'language', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('writing', 'writing', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('reading', 'reading', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('speaking', 'speaking', 'trim|required|strip_all_tags');
		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}

		$language_array = array(
			'language'		=> $this->input->post('language'),
			'writing'		=> $this->input->post('writing'),
			'reading' 		=> $this->input->post('reading'),
			'speaking' 		=> $this->input->post('speaking')
		);
		$this->jobseeker_language_model->update($this->input->post('id'), $language_array);
		$this->session->set_flashdata('msg', '<div class="alert alert-success"> <a href="#" class="close" data-dismiss="alert">&times;</a> <strong>Success!</strong> Your language has been updated successfully. </div>');
		echo "done";
	}

	public function delete()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('id', 'id', 'trim|required|strip_all_tags|numeric');

		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}
		$this->jobseeker_language_model->delete($this->input->post('id'));
		echo "done";
	}

	public function language_by_id()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('id', 'id', 'trim|required|numeric');

		$row = $this->jobseeker_language_model->get_record_by_id($this->input->post('id'));
		echo json_encode($row);
	}
}
