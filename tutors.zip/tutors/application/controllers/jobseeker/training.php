<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Training extends CI_Controller {

	public function index(){
		echo "you are not allow to access this page directly";
		exit;
	}

	public function add()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('title', 'title', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('institute', 'institute', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('year', 'year', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('duration', 'duration', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('location', 'location', 'trim|strip_all_tags');
		$this->form_validation->set_rules('city', 'city', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('country', 'country', 'trim|strip_all_tags');
		$this->form_validation->set_rules('topic_covered', 'topic_covered', 'trim|strip_all_tags');
		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}
		$training_array = array(
			'seeker_ID'		=> $this->session->userdata('user_id'),
			'title'			=> $this->input->post('title'),
			'institute'		=> $this->input->post('institute'),
			'year' 			=> $this->input->post('year'),
			'duration' 		=> $this->input->post('duration'),
			'location' 		=> $this->input->post('location'),
			'city' 			=> $this->input->post('city'),
			'country' 		=> $this->input->post('country'),
			'topic_covered' => $this->input->post('topic_covered')
		);
		$this->jobseeker_training_model->add($training_array);
		$this->session->set_flashdata('msg', '<div class="alert alert-success"> <a href="#" class="close" data-dismiss="alert">&times;</a> <strong>Success!</strong> Your training has been added successfully. </div>');
		echo "done";
	}

	public function edit()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('title', 'title', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('institute', 'institute', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('year', 'year', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('duration', 'duration', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('location', 'location', 'trim|strip_all_tags');
		$this->form_validation->set_rules('city', 'city', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('country', 'country', 'trim|strip_all_tags');
		$this->form_validation->set_rules('topic_covered', 'topic_covered', 'trim|strip_all_tags');
		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}

		$training_array = array(
			'title'			=> $this->input->post('title'),
			'institute'		=> $this->input->post('institute'),
			'year' 			=> $this->input->post('year'),
			'duration' 		=> $this->input->post('duration'),
			'location' 		=> $this->input->post('location'),
			'city' 			=> $this->input->post('city'),
			'country' 		=> $this->input->post('country'),
			'topic_covered' => $this->input->post('topic_covered')
		);
		$this->jobseeker_training_model->update($this->input->post('id'), $training_array);
		$this->session->set_flashdata('msg', '<div class="alert alert-success"> <a href="#" class="close" data-dismiss="alert">&times;</a> <strong>Success!</strong> Your training has been updated successfully. </div>');
		echo "done";
	}

	public function delete()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('id', 'id', 'trim|required|strip_all_tags|numeric');

		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}
		$this->jobseeker_training_model->delete($this->input->post('id'));
		echo "done";
	}

	public function training_by_id()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('id', 'id', 'trim|required|numeric');

		$row = $this->jobseeker_training_model->get_record_by_id($this->input->post('id'));
		echo json_encode($row);
	}
}
