<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Reference extends CI_Controller {

	public function index(){
		echo "you are not allow to access this page directly";
		exit;
	}

	public function add()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('name', 'name', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('designation', 'designation', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('email', 'email', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('relation', 'relation', 'trim|strip_all_tags');
		$this->form_validation->set_rules('organaization', 'organaization', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('phone', 'phone', 'trim|strip_all_tags');
		$this->form_validation->set_rules('address', 'address', 'trim|strip_all_tags');
		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}
		$reference_array = array(
			'seeker_ID'		=> $this->session->userdata('user_id'),
			'name'			=> $this->input->post('name'),
			'designation'	=> $this->input->post('designation'),
			'mobile' 		=> $this->input->post('mobile'),
			'email' 		=> $this->input->post('email'),
			'relation' 		=> $this->input->post('relation'),
			'organaization' => $this->input->post('organaization'),
			'phone' 		=> $this->input->post('phone'),
			'address' 		=> $this->input->post('address')
		);
		$this->jobseeker_reference_model->add($reference_array);
		$this->session->set_flashdata('msg', '<div class="alert alert-success"> <a href="#" class="close" data-dismiss="alert">&times;</a> <strong>Success!</strong> Your reference has been added successfully. </div>');
		echo "done";
	}

	public function edit()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('name', 'name', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('designation', 'designation', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('email', 'email', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('relation', 'relation', 'trim|strip_all_tags');
		$this->form_validation->set_rules('organaization', 'organaization', 'trim|required|strip_all_tags');
		$this->form_validation->set_rules('phone', 'phone', 'trim|strip_all_tags');
		$this->form_validation->set_rules('address', 'address', 'trim|strip_all_tags');
		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}

		$reference_array = array(
			'name'			=> $this->input->post('name'),
			'designation'	=> $this->input->post('designation'),
			'mobile' 		=> $this->input->post('mobile'),
			'email' 		=> $this->input->post('email'),
			'relation' 		=> $this->input->post('relation'),
			'organaization' => $this->input->post('organaization'),
			'phone' 		=> $this->input->post('phone'),
			'address' 		=> $this->input->post('address')
		);
		$this->jobseeker_reference_model->update($this->input->post('id'), $reference_array);
		$this->session->set_flashdata('msg', '<div class="alert alert-success"> <a href="#" class="close" data-dismiss="alert">&times;</a> <strong>Success!</strong> Your reference has been updated successfully. </div>');
		echo "done";
	}

	public function delete()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('id', 'id', 'trim|required|strip_all_tags|numeric');

		if ($this->form_validation->run() === FALSE) {
			echo strip_tags(validation_errors());
			exit;
		}
		$this->jobseeker_reference_model->delete($this->input->post('id'));
		echo "done";
	}

	public function reference_by_id()
	{
		if(!$this->session->userdata('user_id')){
			echo 'Your session has been expired, please re-login first.';
			exit;
		}

		$this->form_validation->set_rules('id', 'id', 'trim|required|numeric');

		$row = $this->jobseeker_reference_model->get_record_by_id($this->input->post('id'));
		echo json_encode($row);
	}
}
