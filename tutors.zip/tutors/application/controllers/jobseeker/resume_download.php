<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

include_once("bootstrap.php");

class Resume_Download extends CI_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index()
	{
		$skills = $this->jobseeker_skills_model->get_records_by_seeker_id($this->session->userdata('user_id'));
		//Qualification
		$result_qualification = $this->job_seekers_model->get_qualification_by_jobseeker_id($this->session->userdata('user_id'));
		//Additional Info
		$row_additional = $this->jobseeker_additional_info_model->get_record_by_userid($this->session->userdata('user_id'));

		$result = $this->job_seekers_model->get_job_seeker_by_id($this->session->userdata('user_id'));

		$fullname = ucwords($result->first_name . $result->last_name);
		$filename = str_replace(" ", "", $fullname);

		//training
		$result_training = $this->job_seekers_model->get_training_by_jobseeker_id($this->session->userdata('user_id'));

		//Language proficiency
		$result_proficiency =$this->job_seekers_model->get_languages_by_jobseeker_id($this->session->userdata('user_id'));

		//Reference
		$result_references =$this->job_seekers_model->get_references_by_jobseeker_id($this->session->userdata('user_id'));

		//Additional Info
		$row_additional = $this->jobseeker_additional_info_model->get_record_by_userid($this->session->userdata('user_id'));

		//Experience
		$result_experience = $this->job_seekers_model->get_experience_by_jobseeker_id($this->session->userdata('user_id'));


		$resume_photo = !empty($result->photo) ? 'public/uploads/candidate/thumb/'.$result->photo : false;

		$address = "Address: " . (isset($result->present_address) ? $result->present_address . ", " : "" ) . (isset($result->city) ? $result->city . ". " : "");
		$mobile_no = "Mobile No: " . (isset($result->mobile) ? $result->mobile : "");
		$email = "Email: " . (isset($result->email) ? $result->email : "");

		$file_path = "public/uploads/candidate/resumes/generated/" . str_replace(" ", "", $filename).".docx";

		// Creating the new document...
		$phpWord = new \PhpOffice\PhpWord\PhpWord();

		$section = $phpWord->addSection();
		$header = array('size' => 16, 'bold' => true, 'color' => '#333399' );


		$imageTableStyle = [];
		$cellRowSpan = array('vMerge' => 'restart', 'valign' => 'center');
		$cellRowContinue = array('vMerge' => 'continue');

		$spanTableStyleName = 'Colspan Rowspan';
		$tableclr = array('size' => '10');
		$phpWord->addTableStyle($spanTableStyleName, $imageTableStyle, $tableclr);
		$table = $section->addTable();

		$fancyTableStyleName = 'Fancy Table';
		$fancyTableStyle = array('borderSize' => 6, 'borderColor' => '000000', 'cellMarginLeft' => 80, 'cellMarginRight' => 80, 'cellMarginTop' => 80, 'alignment' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER);
		$fancyTableFirstRowStyle = array('borderBottomSize' => 6, 'borderBottomColor' => '000000', 'bgColor' => 'FFFFFF');
		$fancyTableCellStyle = array('valign' => 'center');
		$fancyTableCellBtlrStyle = array('valign' => 'center', 'textDirection' => \PhpOffice\PhpWord\Style\Cell::TEXT_DIR_BTLR);
		$fancyTableFontStyle = array('bold' => true);
		$phpWord->addTableStyle($fancyTableStyleName, $fancyTableStyle, $fancyTableFirstRowStyle);

		$table->addRow();

		$cell1 = $table->addCell(8000);
		$cell1->addText(strtoupper($fullname), $header);

		if($resume_photo and file_exists($resume_photo)) {
			$cell1 = $table->addCell(2000, $cellRowSpan);
			$cell1->addImage(base_url($resume_photo), array('width' => 150, 'height' => 150, 'alignment' => \PhpOffice\PhpWord\SimpleType\Jc::CENTER));
		}

		$table->addRow();
		$table->addCell(null, $cellRowContinue);
		$table->addCell(null, $cellRowContinue);

		$table->addRow();
		$table->addCell(8000)->addText($address);
		$table->addCell(null, $cellRowContinue);

		$table->addRow();
		$table->addCell(8000)->addText($mobile_no);
		$table->addCell(null, $cellRowContinue);

		$table->addRow();
		$table->addCell(8000)->addText($email);
		$table->addCell(null, $cellRowContinue);

		$section->addLine([
			'width'       => \PhpOffice\PhpWord\Shared\Converter::cmToPixel(16),
			'height'      => \PhpOffice\PhpWord\Shared\Converter::cmToPixel(0),
			'positioning' => 'absolute',
		]);

		$table = $section->addTable();
		$table->addRow();
		$table->addCell(10000)->addText("Career Objective:", array('size' => '11', 'bold'=>true , 'underline' => "single",));
		$objective = ($row_additional->description) ? character_limiter($row_additional->description,500): ' - ';
		$section->addText($objective);

		if($result_experience) {
			$section->addTextBreak(1);
			$table = $section->addTable($spanTableStyleName);
			$table->addRow();
			$table->addCell(10000)->addText("Employment History:", array('size' => '11','bold'=>true , 'underline' => "single"));
			$i=1;

			foreach ($result_experience as $key => $exp) {

				$end_date = isset($exp->end_date) ? date('F d, Y', strtotime($exp->end_date)) : 'Continuing';
				$section->addText($i . ".  " . $exp->job_title .", ". $exp->department . " (" .$exp->start_date . " - " . $end_date . ")", array('bold'=>true));

				$table = $section->addTable();
				$table->addRow();
				$table->addCell(10000)->addText("	".$exp->company_name);

				$table->addRow();
				$table->addCell()->addText("	Company Location : " . $exp->city . ", " . $exp->country);

				$table->addRow();
				$table->addCell()->addText("	Department : " . $exp->department);

				$table->addRow();
				$table->addCell()->addText("	Duties/Responsibilities");

				$table->addRow();
				$table->addCell()->addText("	".$exp->responsibilities);
				$i++ ;
			}
		}

		if($result_qualification) {
			$section->addTextBreak(1);
			$table = $section->addTable($spanTableStyleName);
			$table->addRow();
			$table->addCell(10000)->addText("Academic Qualification:", array('size' => '11' ,'bold'=>true ,'underline' => "single"));

			$table = $section->addTable($fancyTableStyleName);
			$table->addRow();
			$table->addCell(1750)->addText("Exam Title" , array('bold'=>true));
			$table->addCell(1050)->addText("Concentration/Major" , array('bold'=>true));
			$table->addCell(3000)->addText("Institute" , array('bold'=>true));
			$table->addCell(1500)->addText("Result" , array('bold'=>true));
			$table->addCell(1500)->addText("Pass. Year" , array('bold'=>true));

			foreach($result_qualification as $row_qualification){
				$table->addRow();
				$table->addCell()->addText(isset($row_qualification->degree_title) ? $row_qualification->degree_title : " - ");
				$table->addCell()->addText(isset($row_qualification->major) ? $row_qualification->major : " - ");
				$table->addCell()->addText($row_qualification->institute.', '.$row_qualification->city);
				$table->addCell()->addText("");
				$table->addCell()->addText(isset($row_qualification->completion_year) ? $row_qualification->completion_year : " - ");
			}
		}

		$section->addTextBreak(1);
		$table = $section->addTable($spanTableStyleName);
		$table->addRow();
		$table->addCell(10000)->addText("Training Summary:", array('size' => '11','bold'=>true ,'underline' => "single"));

		$table = $section->addTable($fancyTableStyleName);
		$table->addRow();
		$table->addCell(2000)->addText("Training Title" ,array('bold'=>true));
		$table->addCell(1500)->addText("Topic", array('bold'=>true));
		$table->addCell(2000)->addText("Institute", array('bold'=>true));
		$table->addCell(1000)->addText("Country", array('bold'=>true));
		$table->addCell(1000)->addText("Location", array('bold'=>true));
		$table->addCell(1000)->addText("Year", array('bold'=>true));
		$table->addCell(1000)->addText("Duration", array('bold'=>true));

		if($result_training) {
			foreach($result_training as $row_training){
				$table->addRow();
				$table->addCell()->addText(isset($row_training->title) ? $row_training->title : " - ");
				$table->addCell()->addText(isset($row_training->topic_covered) ? $row_training->topic_covered : " - ");
				$table->addCell()->addText(isset($row_training->institute) ? $row_training->institute : " - ");
				$table->addCell()->addText(isset($row_training->country) ? $row_training->country : " - ");
				$table->addCell()->addText(isset($row_training->location) ? $row_training->location : " - ");
				$table->addCell()->addText(isset($row_training->year) ? $row_training->year : " - ");
				$table->addCell()->addText(isset($row_training->duration) ? $row_training->duration : " - ");
			}
		}

		$section->addTextBreak(1);
		$table = $section->addTable($spanTableStyleName);
		$table->addRow();
		$table->addCell(10000)->addText("Career And Application Information:", array('size' => '11','bold'=>true ,'underline' => "single"));

		$table = $section->addTable();
		$table->addRow();
		$table->addCell(2800)->addText("Present Salary");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($row_additional->salary);

		$table->addRow();
		$table->addCell(2800)->addText("Expected Salary");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($row_additional->expected_salary);

		$table->addRow();
		$table->addCell(2800)->addText("Looking for (Job Level)");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($row_additional->job_level);

		$table->addRow();
		$table->addCell(2800)->addText("Available for (Job Level)");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($row_additional->job_nature);

		$section->addTextBreak(1);
		$table = $section->addTable($spanTableStyleName);
		$table->addRow();
		$table->addCell(10000)->addText("Language proficiency:", array('size' => '11','bold'=>true ,'underline' => "single"));

		$table = $section->addTable($fancyTableStyleName);
		$table->addRow();
		$table->addCell(2250)->addText("Language", array('bold'=>true));
		$table->addCell(2250)->addText("Reading", array('bold'=>true));
		$table->addCell(2250)->addText("Writing", array('bold'=>true));
		$table->addCell(2250)->addText("Speaking", array('bold'=>true));

		if($result_proficiency) {
			foreach($result_proficiency as $row_proficiency){
				$table->addRow();
				$table->addCell(2000)->addText(isset($row_proficiency->language) ? $row_proficiency->language : " - ");
				$table->addCell(2000)->addText(isset($row_proficiency->reading) ? $row_proficiency->reading : " - ");
				$table->addCell(2000)->addText(isset($row_proficiency->writing) ? $row_proficiency->writing : " - ");
				$table->addCell(2000)->addText(isset($row_proficiency->speaking) ? $row_proficiency->speaking : " - ");
			}
		}

		$section->addTextBreak(1);
		$table = $section->addTable($spanTableStyleName);
		$table->addRow();
		$table->addCell(10000)->addText("Specialization:", array('size' => '11','bold'=>true ,'underline' => "single"));

		$table = $section->addTable($fancyTableStyleName);
		$table->addRow();
		$table->addCell(9000)->addText("Fields of Specialization", array('bold'=>true));
		$table->addRow();
		$cell_skill = $table->addCell(9000);
		foreach ($skills as $skill) {
			if(trim($skill->skill_name)!=''){
				$cell_skill->addText(isset($skill->skill_name) ? trim($skill->skill_name) : " - ");
			}
		}

		$section->addTextBreak(1);

		$table = $section->addTable($spanTableStyleName);
		$table->addRow();
		$table->addCell(10000)->addText("Personal Details :", array('size' => '11','bold'=>true ,'underline' => "single"));

		$table = $section->addTable();
		$table->addRow();
		$table->addCell(2800)->addText("Father's Name");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->father_name);

		$table->addRow();
		$table->addCell(2800)->addText("Mother's Name");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->mother_name);

		$table->addRow();
		$table->addCell(2800)->addText("Date of Birth");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->dob);

		$table->addRow();
		$table->addCell(2800)->addText("Gender");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->gender);

		$table->addRow();
		$table->addCell(2800)->addText("Marital Status");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->marital_status);

		$table->addRow();
		$table->addCell(2800)->addText("Nationality");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->nationality);

		$table->addRow();
		$table->addCell(2800)->addText("Religion");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->religion);

		$table->addRow();
		$table->addCell(2800)->addText("Permanent Address");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->permanent_address);

		$table->addRow();
		$table->addCell(2800)->addText("Current Location");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($result->city);

		$table->addRow();
		$table->addCell(2800)->addText("Mobile Phone");
		$table->addCell(200)->addText(":");
		$table->addCell(7000)->addText($mobile_no);

		$section->addTextBreak(1);

		$table = $section->addTable($spanTableStyleName);
		$table->addRow();
		$table->addCell(10000)->addText("Reference :", array('size' => '11','bold'=>true ,'underline' => "single"));

		if($result_references){
			$store_array = [];
			$count = 0;
			foreach($result_references as $row_references){
				$store_array[$count++] = $row_references;
			}
			$table = $section->addTable();
			$table->addRow();
			$table->addCell(2800)->addText("");
			$table->addCell(200)->addText("");
			$table->addCell(3500)->addText("Reference: 01", ['underline' => "single"]);
			$table->addCell(3500)->addText("Reference: 02", ['underline' => "single"]);


			$table->addRow();
			$table->addCell(2800)->addText("Name");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->name);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->name);
			}

			$table->addRow();
			$table->addCell(2800)->addText("Organaization");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->organaization);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->organaization);
			}
			$table->addRow();
			$table->addCell(2800)->addText("Description");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->designation);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->designation);
			}
			$table->addRow();
			$table->addCell(2800)->addText("Address");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->address);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->address);
			}
			$table->addRow();
			$table->addCell(2800)->addText("Phone (off.)");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->phone);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->phone);
			}
			$table->addRow();
			$table->addCell(2800)->addText("Mobile");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->mobile);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->mobile);
			}
			$table->addRow();
			$table->addCell(2800)->addText("E-mail");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->email);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->email);
			}
			$table->addRow();
			$table->addCell(2800)->addText("Relation");
			$table->addCell(200)->addText(":");
			$table->addCell(3500)->addText($store_array[0]->relation);
			if(isset($store_array[1])) {
				$table->addCell(3500)->addText($store_array[1]->relation);
			}
		}

		// Saving the document as OOXML file...
		$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
		$objWriter->save($file_path);
		$download_url = base_url($file_path);
		echo $download_url;
	}

}
