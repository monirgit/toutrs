<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page not found</title>
</head>
<body>
<div class="siteWraper">
  <!--Header-->
  <div class="topheader">
    <div class="navbar navbar-default" role="navigation">
      <div class="container">
        <div class="row">
        </div>
      </div>
    </div>
  </div>
  <!--/Header-->
  <!--Detail Info-->
  <div class="container detailinfo">
    <div class="row">
      <div class="col-md-12"><!--Job Detail-->

        <div class="row">
          <div class="col-md-12 text-center"> <img src="<?php echo base_url('public/images/not-found.jpg') ?>" /> </div>
        </div>
      </div>
      <!--/Job Detail-->

    </div>
  </div>
  <div class="clear">&nbsp;</div>
  <div class="text-center"></div>
  <!--Footer-->

</div>
</body>
</html>
